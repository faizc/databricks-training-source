# Databricks notebook source
dbutils.widgets.removeAll()

dbutils.widgets.text(
    name="CATALOG_NAME",
    defaultValue="dbscannercatalog",
    label="Catalog Name"
)

dbutils.widgets.text(
    name="SCHEMA_NAME",
    defaultValue="catalog_inventory",
    label="Schema Name"
)

dbutils.widgets.text(
    name="VOLUME_NAME",
    defaultValue="adbscanvol",
    label="Volume Name"
)

CATALOG_NAME = dbutils.widgets.get("CATALOG_NAME")
SCHEMA_NAME = dbutils.widgets.get("SCHEMA_NAME")
VOLUME_NAME = dbutils.widgets.get("VOLUME_NAME")

print(f"Using Catalog: {CATALOG_NAME}")
print(f"Using Schema: {SCHEMA_NAME}")
print(f"Using Volume: {VOLUME_NAME}")

# COMMAND ----------

# ════════════════════════════════════════════════════════════════════════════
# STEP 0 — PREFLIGHT PREREQUISITE CHECK  (read-only gate)
#
# Confirms the prerequisites for creating / using the catalog, schemas and volume
# are in place BEFORE the automated creation cell runs.
#   • Prerequisites satisfied -> prints "PREREQS SATISFIED" and lets the next
#     cell proceed exactly as before.
#   • Something required is missing -> prints an itemised PREREQUISITE CHECKLIST,
#     a copy-paste MANUAL RUNBOOK for a Unity Catalog / metastore admin, and
#     STOPS the notebook cleanly (no stack trace, no half-created objects).
#
# NOTE: dbutils.notebook.exit() returns ONLY its message string to a parent
# notebook/job (the printed output below is discarded in that case), so the
# concrete missing items are also embedded into the exit message itself.
#
# ALLOW_AUTO_CREATE: set to True ONLY if you are a metastore admin and want the
# next cell to attempt automatic catalog creation (the original behaviour).
# ════════════════════════════════════════════════════════════════════════════

ALLOW_AUTO_CREATE = True

print("=" * 80)
print("STEP 0: PREFLIGHT PREREQUISITE CHECK")
print("=" * 80 + "\n")

# checks: list of [label, status, detail]   status ∈ {PASS, MISSING, UNKNOWN}
checks = []
missing = []   # concrete missing prerequisites (also embedded in the exit message)
notes = []

def _record(label, status, detail=""):
    checks.append((label, status, detail))

# ── Identity (used in the runbook GRANT statements) ─────────────────────────
try:
    current_user = spark.sql("SELECT current_user() AS u").collect()[0][0]
except Exception:
    current_user = "<your-user>"
print(f"👤 Running as : {current_user}")
print(f"🎯 Target     : catalog='{CATALOG_NAME}', schema='{SCHEMA_NAME}', volume='{VOLUME_NAME}'\n")

# ── Probe 1: Is Unity Catalog reachable on this compute? ────────────────────
existing_catalogs = []
uc_reachable = False
try:
    existing_catalogs = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
    uc_reachable = True
    _record("Unity Catalog reachable on this compute", "PASS")
except Exception as e:
    first_line = str(e).splitlines()[0] if str(e) else "unknown error"
    _record("Unity Catalog reachable on this compute", "MISSING", first_line)
    missing.append("Unity Catalog is not reachable — enable UC on this cluster/warehouse")

# ── Probe 2: Does the target catalog already exist? ─────────────────────────
catalog_exists = CATALOG_NAME in existing_catalogs
if catalog_exists:
    _record(f"Catalog '{CATALOG_NAME}' exists", "PASS")
elif uc_reachable:
    _record(f"Catalog '{CATALOG_NAME}' exists", "MISSING", "not returned by SHOW CATALOGS")
    missing.append(f"Catalog '{CATALOG_NAME}' does not exist yet")

# ── Probe 2b: Do the required schemas already exist? ────────────────────────
if catalog_exists:
    try:
        schemas = [r[0] for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG_NAME}").collect()]
        for s in (SCHEMA_NAME, "catalog_volume"):
            if s in schemas:
                _record(f"Schema '{CATALOG_NAME}.{s}' exists", "PASS")
            else:
                _record(f"Schema '{CATALOG_NAME}.{s}' exists", "MISSING",
                        "next cell will CREATE it (needs CREATE SCHEMA)")
    except Exception as e:
        _record(f"Schemas in '{CATALOG_NAME}' enumerated", "UNKNOWN",
                str(e).splitlines()[0])

# ── Probe 3: Storage building blocks (only relevant when catalog must be made)
ext_locations = []
storage_creds = []
detected_storage_root = None
if uc_reachable and not catalog_exists:
    try:
        ext_locations = [r[0] for r in spark.sql("SHOW EXTERNAL LOCATIONS").collect()]
    except Exception:
        pass
    try:
        storage_creds = [r[0] for r in spark.sql("SHOW STORAGE CREDENTIALS").collect()]
    except Exception:
        pass
    for cat_name in existing_catalogs:
        if cat_name.lower() in ("spark_catalog", "system", "hive_metastore", "samples"):
            continue
        try:
            props = spark.sql(f"DESCRIBE CATALOG EXTENDED {cat_name}").collect()
            d = {r[0].strip(): r[1] for r in props if len(r) >= 2}
            sr = d.get("Storage Root") or d.get("storage_root") or d.get("StorageRoot")
            if sr and str(sr).lower() != "null":
                detected_storage_root = sr
                break
        except Exception:
            continue

    if ext_locations or detected_storage_root:
        detail = f"{len(ext_locations)} external location(s) visible"
        if detected_storage_root:
            detail += "; a reusable managed root was found on an existing catalog"
        _record("A managed storage location is available", "PASS", detail)
    else:
        _record("A managed storage location is available", "UNKNOWN",
                "no external location visible to you; a metastore default root may or may not exist")
        missing.append("A managed storage location for the new catalog "
                       "(metastore default root OR an external location) — ask your admin")

    # CREATE CATALOG privilege cannot be verified read-only without attempting it.
    _record("CREATE CATALOG privilege on the metastore", "UNKNOWN",
            "admin-only by default; cannot be verified without attempting creation")
    missing.append(f"CREATE CATALOG privilege on the metastore for '{current_user}' "
                   "(metastore-admin only)")

    if detected_storage_root:
        notes.append("If the next cell reuses the detected managed root and its access connector "
                     "was deleted/recreated, you will hit UC_AZURE_CREDENTIAL_NOT_FOUND.")

# ── Overall verdict logic ───────────────────────────────────────────────────
# OK to proceed when UC is reachable AND (the catalog already exists OR an admin
# has explicitly opted in to automatic creation).
prereqs_ok = uc_reachable and (catalog_exists or ALLOW_AUTO_CREATE)

if uc_reachable and not catalog_exists and not ALLOW_AUTO_CREATE:
    notes.append("Automatic creation is disabled (ALLOW_AUTO_CREATE = False). An admin can set it "
                 "to True in this cell to let the next cell attempt creation instead.")

# ── Always print the itemised checklist ─────────────────────────────────────
print("-" * 80)
print("PREREQUISITE CHECKLIST")
print("-" * 80)
_icon = {"PASS": "✅", "MISSING": "❌", "UNKNOWN": "❔"}
for label, status, detail in checks:
    line = f"  {_icon.get(status, '•')} [{status:<7}] {label}"
    if detail:
        line += f"  —  {detail}"
    print(line)

# ── Verdict ─────────────────────────────────────────────────────────────────
print("\n" + "-" * 80)
if prereqs_ok:
    print("✅ PREREQUISITES SATISFIED — the next cell can proceed.")
    if not catalog_exists and ALLOW_AUTO_CREATE:
        print("   (ALLOW_AUTO_CREATE = True → the next cell will attempt catalog creation.)")
    for n in notes:
        print(f"   ℹ️  {n}")
    print("-" * 80)
else:
    print("⛔ PREREQUISITES NOT MET — the following must be resolved first:\n")
    for m in missing:
        print(f"   ❌ MISSING: {m}")
    for n in notes:
        print(f"   ℹ️  {n}")

    print("\n" + "=" * 80)
    print("MANUAL RUNBOOK — have a Unity Catalog / metastore admin run this ONCE")
    print("=" * 80)
    print(f"""
-- 1) (Only if reusing an existing connector that was recreated) repair the credential:
-- ALTER STORAGE CREDENTIAL <credential_name>
--   SET azure_managed_identity = (
--     access_connector_id = '/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Databricks/accessConnectors/<connector>'
--   );

-- 2) Create the catalog (pick ONE option)
--    Option A (recommended) — metastore default root, no storage credential needed:
CREATE CATALOG IF NOT EXISTS {CATALOG_NAME};
--    Option B — bind to a verified external location (its 'Test connection' must pass):
-- CREATE CATALOG IF NOT EXISTS {CATALOG_NAME}
--   MANAGED LOCATION 'abfss://<container>@<storage_account>.dfs.core.windows.net/<path>';

-- 3) Create the schemas used by this tool
CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME};
CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.catalog_volume;

-- 4) Create the volume
CREATE VOLUME IF NOT EXISTS {CATALOG_NAME}.catalog_volume.{VOLUME_NAME};

-- 5) Let the notebook runner use them
GRANT USE CATALOG ON CATALOG {CATALOG_NAME} TO `{current_user}`;
GRANT USE SCHEMA, CREATE TABLE ON SCHEMA {CATALOG_NAME}.{SCHEMA_NAME} TO `{current_user}`;
GRANT USE SCHEMA ON SCHEMA {CATALOG_NAME}.catalog_volume TO `{current_user}`;
GRANT READ VOLUME, WRITE VOLUME ON VOLUME {CATALOG_NAME}.catalog_volume.{VOLUME_NAME} TO `{current_user}`;
""")
    if not ext_locations and not catalog_exists:
        print("-- NOTE: no external location was visible to you. If the metastore also has no")
        print("--       default root, use Option B with a location your admin provisions.")
    print("=" * 80)
    print("After the admin finishes, RE-RUN this notebook from the top.")
    print("(Admins/power users: set ALLOW_AUTO_CREATE = True in this cell to let the next")
    print(" cell attempt creation automatically instead.)")
    print("=" * 80)

    # Embed the concrete missing items in the exit message so they are visible even
    # when this notebook is launched from a parent notebook/job (where the printed
    # output above is discarded and only this string is returned).
    _summary = " | ".join(missing) if missing else "prerequisites not met"
    dbutils.notebook.exit(
        f"PREREQS_NOT_MET → {_summary}. "
        f"(ALLOW_AUTO_CREATE={ALLOW_AUTO_CREATE}) See STEP 0 output for the full runbook."
    )


# COMMAND ----------

# DBTITLE 1,Cell 4
print("="*80)
print("STEP 1: DETECTING STORAGE ROOT FROM EXISTING CATALOG")
print("="*80 + "\n")

storage_root = None
detected_catalog = None

try:
    current_catalog = spark.catalog.currentCatalog()
    if current_catalog and current_catalog != 'spark_catalog':
        detected_catalog = current_catalog
        print(f"✓ Current catalog: {detected_catalog}")
except:
    pass

if not detected_catalog:
    print("No current catalog set, searching for catalogs with storage root...")
    catalogs = spark.sql("SHOW CATALOGS").collect()
    
    for cat in catalogs:
        cat_name = cat.catalog
        if cat_name.lower() in ['spark_catalog', 'system', 'hive_metastore']:
            continue
        
        try:
            catalog_props = spark.sql(f"DESCRIBE CATALOG EXTENDED {cat_name}").collect()
            catalog_dict = {row[0].strip(): row[1] for row in catalog_props if len(row) >= 2}
            
            temp_storage_root = (
                catalog_dict.get('Storage Root') or
                catalog_dict.get('storage_root') or
                catalog_dict.get('StorageRoot')
            )
            
            if temp_storage_root and temp_storage_root.lower() != 'null':
                detected_catalog = cat_name
                print(f"✓ Found catalog with storage root: {detected_catalog}")
                break
        except:
            continue

if detected_catalog:
    print(f"\nRetrieving storage root from: {detected_catalog}")
    
    catalog_props = spark.sql(f"DESCRIBE CATALOG EXTENDED {detected_catalog}").collect()
    catalog_dict = {row[0].strip(): row[1] for row in catalog_props if len(row) >= 2}
    
    storage_root = (
        catalog_dict.get('Storage Root') or
        catalog_dict.get('storage_root') or
        catalog_dict.get('StorageRoot') or
        catalog_dict.get('storage root') or
        catalog_dict.get('Location')
    )
    
    if storage_root and storage_root.lower() != 'null':
        print(f"\n✅ SUCCESS! Found Storage Root:")
        print(f"   {storage_root}")
        
        import re
        match = re.match(r'abfss://([^@]+)@([^.]+)\.dfs\.core\.windows\.net/(.+)', storage_root)
        if match:
            container = match.group(1)
            storage_account = match.group(2)
            path = match.group(3)
            
            print(f"\n📁 Storage Details:")
            print(f"   Container: {container}")
            print(f"   Storage Account: {storage_account}")
            print(f"   Path/Root: {path}")
else:
    print(f"\n⚠️  No catalog with storage root found")

print("\n" + "="*80)
print("STEP 2: CREATING NEW CATALOG")
print("="*80 + "\n")

if storage_root:
    print(f"Creating catalog '{CATALOG_NAME}' using storage root from '{detected_catalog}'...\n")
    
    try:
        spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG_NAME} MANAGED LOCATION '{storage_root}'")
        print(f"✅ Catalog '{CATALOG_NAME}' created successfully")
        print(f"   Storage Location: {storage_root}")
    except Exception as e:
        print(f"❌ Error creating catalog: {e}")
        raise
else:
    print(f"⚠️  No storage root detected, attempting to create catalog without managed location...\n")
    
    try:
        spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG_NAME}")
        print(f"✅ Catalog '{CATALOG_NAME}' created successfully")
    except Exception as e:
        print(f"❌ Error: {e}")
        print("\nPlease configure storage root or external location first.")
        raise

print("\nVerifying catalog creation...")
spark.sql("SHOW CATALOGS").show()

print(f"\nSwitching to catalog: {CATALOG_NAME}")
spark.sql(f"USE CATALOG {CATALOG_NAME}")

print("\n" + "="*80)
print("STEP 3: CREATING SCHEMAS AND VOLUME")
print("="*80 + "\n")

print(f"Creating schemas in {CATALOG_NAME}...")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.catalog_inventory")
print(f"✓ Schema 'catalog_inventory' created")

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG_NAME}.catalog_volume")
print(f"✓ Schema 'catalog_volume' created")

print(f"\nCreating volume in {CATALOG_NAME}.catalog_volume...")
spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG_NAME}.catalog_volume.{VOLUME_NAME}")
print(f"✓ Volume '{VOLUME_NAME}' created")

print("\n" + "="*80)
print("✅ SETUP COMPLETE")
print("="*80)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Main summary table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_summary (
# MAGIC   -- Scan Metadata
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   workspace_url STRING,
# MAGIC   scan_start_timestamp TIMESTAMP NOT NULL,
# MAGIC   scan_end_timestamp TIMESTAMP NOT NULL,
# MAGIC   scan_duration_seconds DOUBLE,
# MAGIC   scan_type STRING,
# MAGIC   
# MAGIC   -- Top Row KPIs - Counts
# MAGIC   total_clusters INT,
# MAGIC   total_jobs INT,
# MAGIC   total_pipelines INT,
# MAGIC   total_uc_tables INT,
# MAGIC   total_warehouses INT,
# MAGIC   total_ml_experiments INT,
# MAGIC   total_repos INT,
# MAGIC   total_serving_endpoints INT,
# MAGIC   total_genie_spaces INT,
# MAGIC   total_alerts INT,
# MAGIC   total_notebooks INT,  
# MAGIC   -- Constraints
# MAGIC   PRIMARY KEY (scan_id, workspace_id)
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_start_timestamp)
# MAGIC COMMENT 'Workspace scan summary data for dashboard visualization';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Cluster details table (normalized)
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_clusters (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   cluster_id STRING NOT NULL,
# MAGIC   cluster_name STRING,
# MAGIC   state STRING,
# MAGIC   cluster_source STRING,
# MAGIC   node_type_id STRING,
# MAGIC   driver_node_type_id STRING,
# MAGIC   min_workers INT,
# MAGIC   max_workers INT,
# MAGIC   num_workers INT,
# MAGIC   autotermination_minutes INT,
# MAGIC   creator_user_name STRING,
# MAGIC   uptime_hours DOUBLE,
# MAGIC   spot_enabled BOOLEAN,
# MAGIC   enable_elastic_disk BOOLEAN,
# MAGIC   spark_version STRING,
# MAGIC   policy_id STRING,
# MAGIC   PRIMARY KEY (scan_id, cluster_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Detailed cluster information per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Unity Catalog tables detail
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_uc_tables (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   catalog_name STRING,
# MAGIC   schema_name STRING,
# MAGIC   table_name STRING,
# MAGIC   table_type STRING,  -- MANAGED, EXTERNAL
# MAGIC   table_format STRING,  -- DELTA, PARQUET, CSV, etc.
# MAGIC   storage_location STRING,
# MAGIC   is_delta BOOLEAN,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, catalog_name, schema_name, table_name)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Unity Catalog table details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Warehouse details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_warehouses (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   warehouse_id STRING NOT NULL,
# MAGIC   warehouse_name STRING,
# MAGIC   cluster_size STRING,
# MAGIC   min_num_clusters INT,
# MAGIC   max_num_clusters INT,
# MAGIC   auto_stop_mins INT,
# MAGIC   state STRING,
# MAGIC   warehouse_type STRING,
# MAGIC   enable_photon BOOLEAN,
# MAGIC   enable_serverless_compute BOOLEAN,
# MAGIC   spot_instance_policy STRING,
# MAGIC   creator_name STRING,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, warehouse_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'SQL Warehouse details per scan';
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Pipeline details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_pipelines (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   pipeline_id STRING NOT NULL,
# MAGIC   pipeline_name STRING,
# MAGIC   state STRING,
# MAGIC   creator_user_name STRING,
# MAGIC   creation_time TIMESTAMP,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, pipeline_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'DLT Pipeline details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Jobs details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_jobs (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   job_id STRING NOT NULL,
# MAGIC   job_name STRING,
# MAGIC   creator_user_name STRING,
# MAGIC   job_type STRING,
# MAGIC   schedule STRING,
# MAGIC   max_concurrent_runs INT,
# MAGIC   timeout_seconds INT,
# MAGIC   task_count INT,
# MAGIC   has_notifications BOOLEAN,
# MAGIC   has_retry_policy BOOLEAN,
# MAGIC   tags STRING,
# MAGIC   created_time TIMESTAMP,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, job_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Job details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Notebooks details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_notebooks (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   notebook_path STRING NOT NULL,
# MAGIC   notebook_name STRING,
# MAGIC   language STRING,
# MAGIC   created_by STRING,
# MAGIC   created_time TIMESTAMP,
# MAGIC   last_modified_time TIMESTAMP,
# MAGIC   size_bytes BIGINT,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, notebook_path)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Notebook details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ML Experiments details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_ml_experiments (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   experiment_id STRING NOT NULL,
# MAGIC   experiment_name STRING,
# MAGIC   artifact_location STRING,
# MAGIC   lifecycle_stage STRING,
# MAGIC   creation_time TIMESTAMP,
# MAGIC   last_update_time TIMESTAMP,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, experiment_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'ML Experiment details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Repos details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_repos (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   repo_id STRING NOT NULL,
# MAGIC   repo_path STRING,
# MAGIC   repo_url STRING,
# MAGIC   provider STRING,
# MAGIC   branch STRING,
# MAGIC   head_commit_sha STRING,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, repo_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Git Repo details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Serving Endpoints details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_serving_endpoints (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   endpoint_name STRING NOT NULL,
# MAGIC   endpoint_id STRING,
# MAGIC   model_name STRING,
# MAGIC   model_version STRING,
# MAGIC   state STRING,
# MAGIC   creator STRING,
# MAGIC   creation_timestamp TIMESTAMP,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, endpoint_name)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Serving Endpoint details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Alerts details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_alerts (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   alert_id STRING NOT NULL,
# MAGIC   alert_name STRING,
# MAGIC   query_id STRING,
# MAGIC   state STRING,
# MAGIC   created_by STRING,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, alert_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Alert details per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Genie Spaces details table
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.workspace_scan_genie_spaces (
# MAGIC   workspace_id STRING NOT NULL,
# MAGIC   scan_id STRING NOT NULL,
# MAGIC   space_id STRING NOT NULL,
# MAGIC   space_name STRING,
# MAGIC   description STRING,
# MAGIC   created_by STRING,
# MAGIC   
# MAGIC   PRIMARY KEY (scan_id, space_id)
# MAGIC ) USING DELTA
# MAGIC COMMENT 'Genie Space details per scan';

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plugin 1 — Spark Job Optimizer Tables

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC -- Plugin 1 | Table 1: Spark Job Optimizer Findings
# MAGIC --
# MAGIC -- One row per detected inefficiency across all seven detection categories:
# MAGIC --   data_skew | shuffle_spill | small_files | broadcast_joins
# MAGIC --   long_running_jobs | failed_tasks | delta_issues
# MAGIC --
# MAGIC -- Populated by SparkJobOptimizerAnalyzer when write_to_delta = "Y"
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.spark_job_optimizer_findings (
# MAGIC
# MAGIC   -- Scan correlation
# MAGIC   finding_id         STRING      NOT NULL   COMMENT 'Auto-generated UUID per finding row',
# MAGIC   scan_id            STRING      NOT NULL   COMMENT 'Derived from workspace_id + scan_timestamp (join key)',
# MAGIC   workspace_id       STRING      NOT NULL   COMMENT 'Databricks workspace ID',
# MAGIC   workspace_name     STRING                 COMMENT 'Workspace host URL / name',
# MAGIC   scan_timestamp     TIMESTAMP              COMMENT 'UTC timestamp when the scan started',
# MAGIC   lookback_days      INT                    COMMENT 'Number of historical days analysed',
# MAGIC
# MAGIC   -- Finding classification
# MAGIC   category           STRING                 COMMENT 'data_skew | shuffle_spill | small_files | broadcast_joins | long_running_jobs | failed_tasks | delta_issues',
# MAGIC   severity           STRING                 COMMENT 'HIGH | MEDIUM | LOW based on threshold rules',
# MAGIC
# MAGIC   -- Source identifiers (nullable for table-level detections)
# MAGIC   job_id             STRING                 COMMENT 'Databricks job ID (null for query/table detections)',
# MAGIC   run_id             STRING                 COMMENT 'Job run ID (null for query/table detections)',
# MAGIC   query_id           STRING                 COMMENT 'SQL query statement_id (null for job/table detections)',
# MAGIC
# MAGIC   -- Table reference (null for job/query detections)
# MAGIC   table_catalog      STRING                 COMMENT 'Unity Catalog catalog name',
# MAGIC   table_schema       STRING                 COMMENT 'Unity Catalog schema name',
# MAGIC   table_name         STRING                 COMMENT 'Unity Catalog table name',
# MAGIC
# MAGIC   -- Key detection metrics (nullable; only the relevant columns are populated per category)
# MAGIC   skew_ratio         DOUBLE                 COMMENT 'data_skew: max_task / median_task',
# MAGIC   spill_mb           DOUBLE                 COMMENT 'shuffle_spill: disk spill in MB',
# MAGIC   read_mb            DOUBLE                 COMMENT 'broadcast_joins: total bytes read in MB',
# MAGIC   num_files          BIGINT                 COMMENT 'small_files: number of Delta files in table',
# MAGIC   duration_mins      DOUBLE                 COMMENT 'long_running_jobs: job wall-clock duration in minutes',
# MAGIC   failure_pct        DOUBLE                 COMMENT 'failed_tasks: percentage of failed tasks',
# MAGIC   days_since_alter   INT                    COMMENT 'delta_issues: days since table was last altered',
# MAGIC
# MAGIC   -- Full source row for drilldown / dashboard
# MAGIC   details_json       STRING                 COMMENT 'JSON-serialised source row from system table query',
# MAGIC
# MAGIC   CONSTRAINT pk_sjo_findings PRIMARY KEY (finding_id, scan_id)
# MAGIC
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_timestamp)
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC   'delta.autoOptimize.autoCompact'   = 'true'
# MAGIC )
# MAGIC COMMENT 'Plugin 1 (Spark Job Optimizer): one row per detected Spark inefficiency per scan';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC -- Plugin 1 | Table 2: Spark Job Optimizer Recommendations
# MAGIC --
# MAGIC -- One row per actionable recommendation generated by SparkRecommendationEngine.
# MAGIC -- Each row links back to spark_job_optimizer_findings via finding_id + scan_id.
# MAGIC --
# MAGIC -- Populated by SparkJobOptimizerAnalyzer when write_to_delta = "Y"
# MAGIC -- ─────────────────────────────────────────────────────────────────────────────
# MAGIC CREATE TABLE IF NOT EXISTS catalog_inventory.spark_job_optimizer_recommendations (
# MAGIC
# MAGIC   -- Scan correlation
# MAGIC   recommendation_id  STRING      NOT NULL   COMMENT 'Auto-generated UUID per recommendation',
# MAGIC   scan_id            STRING      NOT NULL   COMMENT 'Join key to spark_job_optimizer_findings',
# MAGIC   workspace_id       STRING                 COMMENT 'Databricks workspace ID',
# MAGIC   scan_timestamp     TIMESTAMP              COMMENT 'UTC timestamp when the scan started',
# MAGIC
# MAGIC   -- Finding linkage
# MAGIC   finding_id         STRING                 COMMENT 'Links to spark_job_optimizer_findings.finding_id',
# MAGIC   category           STRING                 COMMENT 'Same category string as the parent finding',
# MAGIC   priority           STRING                 COMMENT 'HIGH | MEDIUM | LOW',
# MAGIC
# MAGIC   -- Recommendation content
# MAGIC   issue_summary      STRING                 COMMENT 'Human-readable description of the issue',
# MAGIC   actions            STRING                 COMMENT 'Ordered fix steps, newline-separated',
# MAGIC   sql_scripts        STRING                 COMMENT 'Ready-to-run SQL statements, double-newline-separated',
# MAGIC   estimated_savings  STRING                 COMMENT 'Expected performance or DBU cost benefit',
# MAGIC   reference_docs     STRING                 COMMENT 'Databricks documentation URLs, newline-separated',
# MAGIC
# MAGIC   CONSTRAINT pk_sjo_recs PRIMARY KEY (recommendation_id, scan_id)
# MAGIC
# MAGIC ) USING DELTA
# MAGIC PARTITIONED BY (scan_timestamp)
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC   'delta.autoOptimize.autoCompact'   = 'true'
# MAGIC )
# MAGIC COMMENT 'Plugin 1 (Spark Job Optimizer): actionable recommendations linked to findings';

# COMMAND ----------

#Validate created tables
spark.sql(f"SHOW TABLES IN {CATALOG_NAME}.catalog_inventory").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create required folders in Volume

# COMMAND ----------

import os

# Volume base path
volume_path = f"/Volumes/{CATALOG_NAME}/catalog_volume/{VOLUME_NAME}"

# Create 'script' and 'out' directories
try:
    dbutils.fs.mkdirs(f"{volume_path}/script")
    dbutils.fs.mkdirs(f"{volume_path}/out")
    print(f"✓ Created directories: {volume_path}/script and {volume_path}/out")
except Exception as e:
    print(f"Note: Directories may already exist or error occurred: {e}")

# List volume contents to verify
print(f"\nVolume contents:")
display(dbutils.fs.ls(volume_path))