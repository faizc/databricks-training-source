# Databricks notebook source
# MAGIC %md
# MAGIC # Databricks Workspace Discovery Scanner
# MAGIC
# MAGIC This notebook performs an automated discovery of Databricks workspace assets, configurations, and usage patterns.  
# MAGIC It is designed to help administrators gain visibility into workspace structure, Cluster Information, Job Details, Pipelines, unity catalog, security information, utilization metrics , and operational artifacts.
# MAGIC
# MAGIC
# MAGIC ### Key Outcomes
# MAGIC - Workspace-wide inventory of compute, jobs, pipelines, and governance objects
# MAGIC - Utilization and cost-related signals to support optimization discussions
# MAGIC - Structured outputs for cataloging of Databricks Assets in a workspace

# COMMAND ----------

# MAGIC %md
# MAGIC ## Environment Setup and Toolkit Installation
# MAGIC
# MAGIC This cell installs and initializes the required Databricks Toolkit components used for workspace discovery.
# MAGIC It ensures that all supporting libraries and dependencies are consistently available before execution begins.
# MAGIC
# MAGIC **Why this matters**
# MAGIC - Guarantees version-aligned tooling
# MAGIC - Avoids dependency conflicts during scan execution
# MAGIC - Enables repeatable execution across workspaces and environments
# MAGIC

# COMMAND ----------

# -------------------------------------------------------------------
# Spark Job Optimizer — Delta Write Widget
# Run this cell first, then set the dropdown at the top of the
# notebook before executing the scan.  Matching the confirm_insert
# pattern used in 02_generate_all_analysis.
# -------------------------------------------------------------------
dbutils.widgets.removeAll()
dbutils.widgets.dropdown(
    name         = "write_to_delta",
    defaultValue = "N",
    choices      = ["N", "Y"],
    label        = "Write Spark Optimizer results to Delta Tables?"
)

dbutils.widgets.text(
    name         = "WORKSPACE_URL",
    defaultValue = "",
    label        = "Workspace URL"
)
dbutils.widgets.text(
    name         = "ACCOUNT_ID",
    defaultValue = "",
    label        = "Account ID (optional - for account-level security scans)"
)
dbutils.widgets.text(
    name         = "DISCOVERY_OUTPUT",
    defaultValue = "/Volumes/dbscannercatalog/catalog_volume/adbscanvol/out/discovery/",
    label        = "Output Directory"
)

dbutils.widgets.dropdown(
    name         = "SCAN_TYPE",
    defaultValue = "deep",
    choices      = ["simple", "deep"],
    label        = "Scan Type"
)
dbutils.widgets.dropdown(
    name         = "UC_SCAN",
    defaultValue = "partial",
    choices      = ["skip", "partial", "complete"],
    label        = "UC Scan Mode"
)
dbutils.widgets.dropdown(
    name         = "BILLING_ENABLED",
    defaultValue = "Y",
    choices      = ["Y", "N"],
    label        = "Enable Billing Data"
)
dbutils.widgets.text(
    name         = "BILLING_DAYS",
    defaultValue = "30",
    label        = "Billing Days (1-30)"
)
dbutils.widgets.text(
    name         = "UTILIZATION_DAYS",
    defaultValue = "30",
    label        = "Utilization Days"
)
dbutils.widgets.dropdown(
    name         = "EXPORT_FORMAT",
    defaultValue = "json",
    choices      = ["json", "csv"],
    label        = "Export Format"
)
dbutils.widgets.text(
    name         = "MAX_WORKERS",
    defaultValue = "6",
    label        = "Max parallel workers"
)

dbutils.widgets.text(
    name         = "discovery_catalog",
    defaultValue = "dbscannercatalog",
    label        = "Discovery Table Catalog"
)

dbutils.widgets.text(
    name         = "SQL_WAREHOUSE_ID",
    defaultValue = "",
    label        = "SQL Warehouse ID (blank = auto-detect serverless)"
)


# print("Widget created above ↑  —  set to 'Y' to persist findings to Delta tables.")

# COMMAND ----------

# Replace the path with your wheel file location
%pip install --force-reinstall --no-deps --no-cache-dir /Volumes/dbscannercatalog/catalog_volume/adbscanvol/script/databricks_toolkit-3.0.2-py3-none-any.whl

# COMMAND ----------

# MAGIC %pip install databricks-sdk --upgrade

# COMMAND ----------

# Restart Python to load the newly installed package
dbutils.library.restartPython()

# COMMAND ----------

import pkg_resources
print(pkg_resources.get_distribution("databricks-sdk").version)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scan Configuration
# MAGIC
# MAGIC This section defines all configurable parameters that control the discovery scan behavior.
# MAGIC
# MAGIC ### Key Settings
# MAGIC - **Workspace URL** – Target Databricks workspace
# MAGIC - **Scan Type** – Simple or Deep (controls metadata vs. utilization depth)
# MAGIC - **Unity Catalog Mode** – Partial or Complete hierarchy scan
# MAGIC - **Billing & Utilization Windows** – Defines historical analysis range
# MAGIC - **Parallelism Controls** – Worker concurrency to balance performance and load
# MAGIC
# MAGIC These parameters should be reviewed and customized per environment before running the scan.

# COMMAND ----------

from databricks_toolkit.discovery import ScanConfig, WorkspaceDiscoveryScanner

# ===================================================================
# CONFIGURATION - Update these values for your environment
# ===================================================================

# Get workspace URL from widget
WORKSPACE_URL = dbutils.widgets.get("WORKSPACE_URL")

# Output directory where discovery data will be saved
DISCOVERY_OUTPUT = dbutils.widgets.get("DISCOVERY_OUTPUT")

# Scan configuration from widgets
SCAN_TYPE = dbutils.widgets.get("SCAN_TYPE")                            # 'simple' or 'deep' (deep collects utilization metrics)
UC_SCAN = dbutils.widgets.get("UC_SCAN")                                # 'partial' (faster, tables only) or 'complete' (full hierarchy)
BILLING_ENABLED = dbutils.widgets.get("BILLING_ENABLED")               # 'Y' to collect billing data, 'N' to skip

# Convert string widget values to integers (widgets always return strings)
BILLING_DAYS = int(dbutils.widgets.get("BILLING_DAYS"))                # Number of days of billing data to collect (1-365)
UTILIZATION_DAYS = int(dbutils.widgets.get("UTILIZATION_DAYS"))        # Number of days of utilization metrics (for deep scan)
MAX_WORKERS = int(dbutils.widgets.get("MAX_WORKERS"))                  # Parallel threads (1-10, higher = faster but more load)

# Other settings
EXPORT_FORMAT = dbutils.widgets.get("EXPORT_FORMAT")                    # 'json' or 'csv'

# Optional: Account ID for account-level security scanning
ACCOUNT_ID = dbutils.widgets.get("ACCOUNT_ID").strip() or None          # Empty string becomes None

discovery_catalog= dbutils.widgets.get("discovery_catalog")

# SQL warehouse used to run system-table queries (cluster / query / job / UC / cost).
# Blank => auto-detect a serverless warehouse (falls back to any running warehouse).
# Provide a provisioned (Classic/Pro) warehouse ID to force its use; if it is
# stopped it will be started and waited on before queries run.
SQL_WAREHOUSE_ID = dbutils.widgets.get("SQL_WAREHOUSE_ID").strip()

# -------------------------------------------------------------------
# Plugin 1 — Spark Job Optimizer  (requires scan_type = 'deep')
# Set 'enabled' to True to activate. All other keys are optional.
# -------------------------------------------------------------------
SPARK_JOB_OPTIMIZER_CONFIG = {
    "enabled": True,                    # Set True to run the plugin
    "warehouse_id": SQL_WAREHOUSE_ID,   # SQL warehouse for system-table queries (auto-detected if blank)
    "lookback_days": UTILIZATION_DAYS,  # History window in days
    "skew_threshold": 10.0,             # Data-skew ratio that triggers a finding
    "spill_threshold_mb": 500.0,        # Shuffle-spill MB that triggers a finding
    "small_files_threshold": 1000,      # File count that triggers a small-files finding
    "output_dir": DISCOVERY_OUTPUT + "spark_optimizer/",  # Where to write the Excel report
    "write_to_delta": dbutils.widgets.get("write_to_delta"),  # set via widget above
    "discovery_catalog": dbutils.widgets.get("discovery_catalog"),
    "discovery_schema":  "catalog_inventory",
}

print("✓ Configuration loaded")
print(f"  Workspace: {WORKSPACE_URL}")
print(f"  Output: {DISCOVERY_OUTPUT}")
print(f"  Scan Type: {SCAN_TYPE}")
print(f"  UC Scan Mode: {UC_SCAN}")
print(f"  SQL Warehouse: {SQL_WAREHOUSE_ID or 'auto-detect (serverless)'}")
print(f"  Spark Job Optimizer: {'Enabled' if SPARK_JOB_OPTIMIZER_CONFIG['enabled'] else 'Disabled'}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pre-processing - Copy existing discovery data to Backup

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════
# PRE-WORK: Back up existing discovery + analysis output before a fresh scan
# ---------------------------------------------------------------------------
# Copies BOTH  .../out/discovery/  and  .../out/analysis/  into a single
# timestamped backup folder  .../out/data_bk_<YYYYMMDD_HHMMSS>/  and then
# deletes the originals from  .../out/ .  This keeps each run starting from a
# clean, single-workspace layout while preserving prior results.
# Existing flat processing logic (scanner + analyzer) stays unchanged.
# ═══════════════════════════════════════════════════════════════════════════
import os, shutil
from datetime import datetime

_disc_dir = DISCOVERY_OUTPUT.rstrip('/').rstrip('\\')   # .../out/discovery
_parent   = os.path.dirname(_disc_dir)                  # .../out
_anly_dir = os.path.join(_parent, 'analysis')           # .../out/analysis

# Only back up folders that actually exist and have content
_to_backup = [d for d in (_disc_dir, _anly_dir)
              if os.path.isdir(d) and os.listdir(d)]

if _to_backup:
    _stamp      = datetime.now().strftime('%Y%m%d_%H%M%S')
    _backup_dir = os.path.join(_parent, f"data_bk_{_stamp}")
    if os.path.exists(_backup_dir):                      # same-second collision guard
        _backup_dir = f"{_backup_dir}_{datetime.now().microsecond}"
    os.makedirs(_backup_dir, exist_ok=True)

    # 1) Copy every existing folder into the backup FIRST, so nothing is
    #    deleted until all copies have succeeded (safe, transactional backup).
    #    copy_function=shutil.copy avoids per-file utime/copystat errors that
    #    can occur on Volumes/DBFS FUSE mounts (metadata not needed for backup).
    for _src in _to_backup:
        _dst = os.path.join(_backup_dir, os.path.basename(_src))
        shutil.copytree(_src, _dst, copy_function=shutil.copy)
        print(f"📦 Copied {_src}  →  {_dst}")

    # 2) Only after ALL copies succeed, delete the originals from out/.
    for _src in _to_backup:
        shutil.rmtree(_src)
        print(f"🗑️  Removed original: {_src}")

    print(f"✓ Backup complete: {_backup_dir}")
else:
    print("✓ No existing discovery/analysis output to back up")

# Recreate an empty discovery/ folder for this run's scan output
os.makedirs(_disc_dir, exist_ok=True)
print(f"✓ Fresh discovery folder ready: {_disc_dir}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Run Discovery Scan
# MAGIC This initializes the workspace discovery scanner using the provided configuration and save results to the specified output directory.

# COMMAND ----------

# Create scan configuration
config = ScanConfig(
    scan_type=SCAN_TYPE,
    workspace_urls=[WORKSPACE_URL],
    uc_scan=UC_SCAN,
    billing_details=BILLING_ENABLED,
    billing_days=BILLING_DAYS,              # Now properly typed as int
    utilization_days=UTILIZATION_DAYS,      # Now properly typed as int
    export_format=EXPORT_FORMAT,
    max_workers=MAX_WORKERS,                # Now properly typed as int
    output_file=DISCOVERY_OUTPUT,
    account_id=ACCOUNT_ID,                  # Optional, from widget (None if not provided)
    log_level='INFO',
    collect_size_metrics = True,
    warehouse_id=(SQL_WAREHOUSE_ID or None),  # Explicit SQL warehouse (blank => auto-detect serverless)
    discovery_catalog=(discovery_catalog or None),  # Skipped from UC DESCRIBE DETAIL size metrics
    spark_job_optimizer=SPARK_JOB_OPTIMIZER_CONFIG
)

print("="*80)
print("STARTING WORKSPACE DISCOVERY SCAN")
print("="*80)
print(f"\nScan Configuration:")
print(f"  • Scan Type: {config.scan_type.upper()}")
print(f"  • UC Scan: {config.uc_scan.upper()}")
print(f"  • Billing: {'Enabled' if config.is_billing_enabled() else 'Disabled'} ({config.billing_days} days)")
print(f"  • Utilization: {config.utilization_days} days")
print(f"  • Workers: {config.max_workers}")
print(f"  • Format: {config.export_format.upper()}")
print(f"  • SQL Warehouse: {config.warehouse_id or 'auto-detect (serverless)'}")
print(f"  • Discovery Catalog (skipped in UC size metrics): {config.discovery_catalog or 'none'}")
print(f"\n" + "="*80 + "\n")

# Initialize scanner and run
scanner = WorkspaceDiscoveryScanner(config)
results = scanner.scan_workspaces()

print(f"\n" + "="*80)
print("✓ DISCOVERY SCAN COMPLETE")
print("="*80)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scan Results Summary Catalog Dashboards
# MAGIC
# MAGIC This section summarizes the overall completion of the discovery scan.
# MAGIC It reports execution duration, scan tier performance, and artifact coverage.
# MAGIC
# MAGIC ✅ Successful completion indicates:
# MAGIC - All configured scan tiers executed
# MAGIC - Results available for analysis and populated in Dashboard
# MAGIC - Output artifacts written to storage

# COMMAND ----------

# DBTITLE 1,Cell 10
from pyspark.sql import Row
from pyspark.sql.functions import to_timestamp, col, from_unixtime
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, LongType, DoubleType, BooleanType, TimestampType
from datetime import datetime

import uuid

# Helper to extract artifact counts safely
def get_count(artifacts, key, default=0):
    val = artifacts.get(key, {})
    if isinstance(val, dict):
        return int(val.get('total_count', default))
    elif isinstance(val, list):
        return int(len(val))
    return int(default)

# Helper to safely get nested dict values
def get_nested(artifacts, key, subkey, default=0):
    val = artifacts.get(key, {})
    if isinstance(val, dict):
        subval = val.get(subkey, default)
        # Handle case where subval might be a list
        if isinstance(subval, list):
            return int(len(subval))
        return int(subval)
    return int(default)

# Helper to convert timestamp - handles both milliseconds (int) and date strings
def convert_timestamp(ts_value):
    if ts_value is None:
        return None
    if isinstance(ts_value, int):
        # Millisecond timestamp
        return int(ts_value / 1000)
    elif isinstance(ts_value, str):
        # Date string like "01/23/2026 18:00:06"
        try:
            dt = datetime.strptime(ts_value, '%m/%d/%Y %H:%M:%S')
            return int(dt.timestamp())
        except:
            return None
    return None

# Prepare rows for DataFrame
cur_scan_id=str(uuid.uuid4())
print(f"\n{'='*80}")
print(f"CURRENT SCAN ID: {cur_scan_id}")
print(f"{'='*80}\n")
rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    
    # Get per-workspace scan timing (fields are at workspace level, not in metadata)
    scan_start_time = ws.get('scan_start_time', results['scan_metadata'].get('start_time', ''))
    scan_end_time = ws.get('scan_end_time', results['scan_metadata'].get('end_time', ''))
    scan_duration = float(ws.get('scan_duration_seconds', results['scan_metadata'].get('total_duration_seconds', 0.0)))
    
    # DEBUG: Check what get_nested returns for alerts
    total_alerts_calculated = get_nested(artifacts, 'workspace_objects', 'alerts')
    
    row = Row(
        scan_id=cur_scan_id,
        workspace_id=ws.get('workspace_id', ''),
        workspace_url=ws.get('workspace_url', ''),
        scan_start_timestamp=scan_start_time,
        scan_end_timestamp=scan_end_time,
        scan_duration_seconds=scan_duration,
        scan_type=results['scan_metadata'].get('scan_type', ''),
        total_clusters=get_count(artifacts, 'clusters'),
        total_jobs=get_count(artifacts, 'jobs'),
        total_pipelines=get_count(artifacts, 'pipelines'),
        total_uc_tables=int(artifacts.get('unity_catalog', {}).get('summary', {}).get('total_tables', 0)),
        total_warehouses=get_count(artifacts, 'warehouses'),
        total_ml_experiments=get_nested(artifacts, 'workspace_objects', 'experiments'),
        total_repos=get_nested(artifacts, 'workspace_objects', 'repos'),
        total_serving_endpoints=get_nested(artifacts, 'workspace_objects', 'serving_endpoints'),
        total_genie_spaces=get_nested(artifacts, 'workspace_objects', 'genie_spaces'),
        total_alerts=total_alerts_calculated,
        total_notebooks=get_nested(artifacts, 'workspace_objects', 'notebooks')
    )
    rows.append(row)

df = spark.createDataFrame(rows)

# Convert scan_timestamp string to timestamp type
df = df.withColumn('scan_start_timestamp', to_timestamp('scan_start_timestamp'))
df = df.withColumn('scan_end_timestamp', to_timestamp('scan_end_timestamp'))

# Cast all integer columns to int type to match table schema
int_columns = [
    'total_clusters', 'total_jobs', 'total_pipelines', 'total_uc_tables', 'total_warehouses',
    'total_ml_experiments', 'total_repos','total_serving_endpoints', 'total_genie_spaces', 'total_alerts', 'total_notebooks'
]

for col_name in int_columns:
    df = df.withColumn(col_name, col(col_name).cast('int'))

df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_summary")

cluster_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    clusters = artifacts.get('clusters', {}).get('items', []) if isinstance(artifacts.get('clusters', {}), dict) else artifacts.get('clusters', [])
    for c in clusters:
        cluster_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            cluster_id=c.get('cluster_id', ''),
            cluster_name=c.get('cluster_name', ''),
            state=c.get('state', ''),
            cluster_source=c.get('cluster_source', ''),
            node_type_id=c.get('node_type_id', ''),
            driver_node_type_id=c.get('driver_node_type_id', ''),
            min_workers=c.get('min_workers'),
            max_workers=c.get('max_workers'),
            num_workers=c.get('num_workers'),
            autotermination_minutes=c.get('autotermination_minutes'),
            creator_user_name=c.get('creator_user_name', ''),
            uptime_hours=c.get('uptime_hours'),
            spot_enabled=c.get('spot', c.get('spot_enabled', None)),
            enable_elastic_disk=c.get('enable_elastic_disk'),
            spark_version=c.get('spark_version', ''),
            policy_id=c.get('policy_id', '')
        ))

cluster_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("cluster_id", StringType(), False),
    StructField("cluster_name", StringType(), True),
    StructField("state", StringType(), True),
    StructField("cluster_source", StringType(), True),
    StructField("node_type_id", StringType(), True),
    StructField("driver_node_type_id", StringType(), True),
    StructField("min_workers", IntegerType(), True),
    StructField("max_workers", IntegerType(), True),
    StructField("num_workers", IntegerType(), True),
    StructField("autotermination_minutes", IntegerType(), True),
    StructField("creator_user_name", StringType(), True),
    StructField("uptime_hours", DoubleType(), True),
    StructField("spot_enabled", BooleanType(), True),
    StructField("enable_elastic_disk", BooleanType(), True),
    StructField("spark_version", StringType(), True),
    StructField("policy_id", StringType(), True)
])

cluster_df = spark.createDataFrame(cluster_rows, schema=cluster_schema)
cluster_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_clusters")

# Unity Catalog Tables Processing
# Check if Unity Catalog was scanned or skipped
uc_skipped = False
uc_table_rows = []

# Check if any workspace has UC data
has_uc_data = any("unity_catalog" in ws.get("artifacts", {}) for ws in results.get("workspaces", []))

if not has_uc_data:
    print("⏭️  Unity Catalog scanning was SKIPPED - no UC data to process")
    uc_skipped = True
else:
    for ws in results.get("workspaces", []):
        artifacts = ws.get("artifacts", {})
        uc = artifacts.get("unity_catalog", {})
        tables = []
        # Try summary->tables, else fallback to tables key
        if isinstance(uc, dict):
            if "tables" in uc:
                tables = uc["tables"]
            elif "summary" in uc and "tables" in uc["summary"]:
                tables = uc["summary"]["tables"]
        for t in tables:
            uc_table_rows.append(Row(
                workspace_id=ws.get("workspace_id", ""),
                scan_id=cur_scan_id,
                catalog_name=t.get("catalog_name", ""),
                schema_name=t.get("schema_name", ""),
                table_name=t.get("table_name", ""),
                table_type=t.get("table_type", ""),
                table_format=t.get("data_source_format") if t.get("data_source_format") is not None else "",
                storage_location=t.get("metastore_path") if t.get("data_source_format") is not None else "",
                is_delta=bool(t.get("is_delta", False))
            ))

# Define schema
uc_table_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("catalog_name", StringType(), True),
    StructField("schema_name", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("table_type", StringType(), True),
    StructField("table_format", StringType(), True),
    StructField("storage_location", StringType(), True),
    StructField("is_delta", BooleanType(), True)
])

# Only create and save DataFrame if there is UC data
if not uc_skipped and len(uc_table_rows) > 0:
    workspace_scan_uc_tables_df = spark.createDataFrame(uc_table_rows, schema=uc_table_schema)
    workspace_scan_uc_tables_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_uc_tables")
    print(f"✅ Inserted {len(uc_table_rows)} Unity Catalog table rows")
elif uc_skipped:
    print("ℹ️  UC Scanning Skipped - No Unity Catalog data written to workspace_scan_uc_tables")
else:
    print("⚠️  No Unity Catalog tables found in scan results")

warehouse_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    warehouses = artifacts.get('warehouses', {}).get('items', []) if isinstance(artifacts.get('warehouses', {}), dict) else artifacts.get('warehouses', [])
    for w in warehouses:
        warehouse_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            warehouse_id=w.get('warehouse_id', ''),
            warehouse_name=w.get('warehouse_name', ''),
            cluster_size=w.get('cluster_size', ''),
            min_num_clusters=w.get('min_num_clusters'),
            max_num_clusters=w.get('max_num_clusters'),
            auto_stop_mins=w.get('auto_stop_mins'),
            state=w.get('state', ''),
            warehouse_type=w.get('warehouse_type', ''),
            enable_photon=w.get('enable_photon'),
            enable_serverless_compute=w.get('enable_serverless_compute'),
            spot_instance_policy=w.get('spot_instance_policy', ''),
            creator_name=w.get('creator_name', '')
        ))

warehouse_schema = StructType([
    StructField("workspace_id", StringType(), True),
    StructField("scan_id", StringType(), False),
    StructField("warehouse_id", StringType(), False),
    StructField("warehouse_name", StringType(), True),
    StructField("cluster_size", StringType(), True),
    StructField("min_num_clusters", IntegerType(), True),
    StructField("max_num_clusters", IntegerType(), True),
    StructField("auto_stop_mins", IntegerType(), True),
    StructField("state", StringType(), True),
    StructField("warehouse_type", StringType(), True),
    StructField("enable_photon", BooleanType(), True),
    StructField("enable_serverless_compute", BooleanType(), True),
    StructField("spot_instance_policy", StringType(), True),
    StructField("creator_name", StringType(), True)
])

warehouse_df = spark.createDataFrame(warehouse_rows, schema=warehouse_schema)
warehouse_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_warehouses")

pipeline_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    pipelines = artifacts.get('pipelines', {}).get('items', []) if isinstance(artifacts.get('pipelines', {}), dict) else artifacts.get('pipelines', [])
    for p in pipelines:
        # Use helper function to convert timestamp
        creation_time = convert_timestamp(p.get('creation_time'))
        
        pipeline_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            pipeline_id=p.get('pipeline_id', ''),
            pipeline_name=p.get('name', ''),
            state=p.get('state', ''),
            creator_user_name=p.get('creator_user_name', ''),
            creation_time=creation_time
        ))

pipeline_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("pipeline_id", StringType(), False),
    StructField("pipeline_name", StringType(), True),
    StructField("state", StringType(), True),
    StructField("creator_user_name", StringType(), True),
    StructField("creation_time", LongType(), True)
])

pipeline_df = spark.createDataFrame(pipeline_rows, schema=pipeline_schema)
# Convert Unix timestamps (seconds) to timestamp type
pipeline_df = pipeline_df.withColumn("creation_time", from_unixtime(col("creation_time")).cast(TimestampType()))
pipeline_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_pipelines")

# Insert Jobs Details
job_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    
    # Handle both 'items' and 'jobs' keys (scanner outputs 'jobs', not 'items')
    jobs_data = artifacts.get('jobs', {})
    if isinstance(jobs_data, dict):
        jobs = jobs_data.get('items', jobs_data.get('jobs', []))
    else:
        jobs = jobs_data if isinstance(jobs_data, list) else []
    
    print(f"DEBUG: Found {len(jobs)} jobs in workspace {ws.get('workspace_id', '')}")
    
    for j in jobs:
        settings = j.get('settings', {})
        # Use helper function to convert timestamp
        created_time = convert_timestamp(j.get('created_time'))
        
        job_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            job_id=str(j.get('job_id', '')),
            job_name=settings.get('name', ''),
            creator_user_name=j.get('creator_user_name', ''),
            job_type=settings.get('format', ''),
            schedule=str(settings.get('schedule', '')),
            max_concurrent_runs=settings.get('max_concurrent_runs'),
            timeout_seconds=settings.get('timeout_seconds'),
            task_count=len(settings.get('tasks', [])),
            has_notifications=bool(settings.get('email_notifications') or settings.get('webhook_notifications')),
            has_retry_policy=bool(settings.get('max_retries', 0) > 0),
            tags=str(settings.get('tags', {})),
            created_time=created_time
        ))

job_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("job_id", StringType(), False),
    StructField("job_name", StringType(), True),
    StructField("creator_user_name", StringType(), True),
    StructField("job_type", StringType(), True),
    StructField("schedule", StringType(), True),
    StructField("max_concurrent_runs", IntegerType(), True),
    StructField("timeout_seconds", IntegerType(), True),
    StructField("task_count", IntegerType(), True),
    StructField("has_notifications", BooleanType(), True),
    StructField("has_retry_policy", BooleanType(), True),
    StructField("tags", StringType(), True),
    StructField("created_time", LongType(), True)
])

job_df = spark.createDataFrame(job_rows, schema=job_schema)
print(f"DEBUG: Inserting {job_df.count()} job rows into table")
# Convert Unix timestamps (seconds) to timestamp type
job_df = job_df.withColumn("created_time", from_unixtime(col("created_time")).cast(TimestampType()))
job_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_jobs")

# Insert Notebooks Details - FIXED FIELD NAMES
notebook_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    notebooks = artifacts.get('workspace_objects', {}).get('notebooks', [])
    for nb in notebooks:
        # Use helper function to convert timestamps
        created_time = convert_timestamp(nb.get('created_at'))
        modified_time = convert_timestamp(nb.get('modified_at'))
        
        notebook_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            notebook_path=nb.get('notebook_path', ''),
            notebook_name=nb.get('notebook_name', ''),
            language=nb.get('language', ''),
            created_by=nb.get('notebook_author', ''),
            created_time=created_time,
            last_modified_time=modified_time,
            size_bytes=nb.get('size')
        ))

notebook_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("notebook_path", StringType(), False),
    StructField("notebook_name", StringType(), True),
    StructField("language", StringType(), True),
    StructField("created_by", StringType(), True),
    StructField("created_time", LongType(), True),
    StructField("last_modified_time", LongType(), True),
    StructField("size_bytes", LongType(), True)
])

notebook_df = spark.createDataFrame(notebook_rows, schema=notebook_schema)
# Convert Unix timestamps (seconds) to timestamp type
notebook_df = notebook_df.withColumn("created_time", from_unixtime(col("created_time")).cast(TimestampType()))
notebook_df = notebook_df.withColumn("last_modified_time", from_unixtime(col("last_modified_time")).cast(TimestampType()))
notebook_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_notebooks")

# Insert ML Experiments Details
ml_exp_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    experiments = artifacts.get('workspace_objects', {}).get('experiments', [])
    for exp in experiments:
        # Use helper function to convert timestamps
        creation_time = convert_timestamp(exp.get('creation_time'))
        last_update_time = convert_timestamp(exp.get('last_update_time'))
        
        ml_exp_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            experiment_id=str(exp.get('experiment_id', '')),
            experiment_name=exp.get('name', ''),
            artifact_location=exp.get('artifact_location', ''),
            lifecycle_stage=exp.get('lifecycle_stage', ''),
            creation_time=creation_time,
            last_update_time=last_update_time
        ))

ml_exp_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("experiment_id", StringType(), False),
    StructField("experiment_name", StringType(), True),
    StructField("artifact_location", StringType(), True),
    StructField("lifecycle_stage", StringType(), True),
    StructField("creation_time", LongType(), True),
    StructField("last_update_time", LongType(), True)
])

ml_exp_df = spark.createDataFrame(ml_exp_rows, schema=ml_exp_schema)
# Convert Unix timestamps (seconds) to timestamp type
ml_exp_df = ml_exp_df.withColumn("creation_time", from_unixtime(col("creation_time")).cast(TimestampType()))
ml_exp_df = ml_exp_df.withColumn("last_update_time", from_unixtime(col("last_update_time")).cast(TimestampType()))
ml_exp_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_ml_experiments")

# Insert Repos Details
repo_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    repos = artifacts.get('workspace_objects', {}).get('repos', [])
    for repo in repos:
        repo_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            repo_id=str(repo.get('id', '')),
            repo_path=repo.get('path', ''),
            repo_url=repo.get('url', ''),
            provider=repo.get('provider', ''),
            branch=repo.get('branch', ''),
            head_commit_sha=repo.get('head_commit_sha', '')
        ))

repo_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("repo_id", StringType(), False),
    StructField("repo_path", StringType(), True),
    StructField("repo_url", StringType(), True),
    StructField("provider", StringType(), True),
    StructField("branch", StringType(), True),
    StructField("head_commit_sha", StringType(), True)
])

repo_df = spark.createDataFrame(repo_rows, schema=repo_schema)
repo_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_repos")

# Insert Serving Endpoints Details
serving_ep_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    endpoints = artifacts.get('workspace_objects', {}).get('serving_endpoints', [])
    print(f"DEBUG: Found {len(endpoints)} serving endpoints in workspace {ws.get('workspace_id', '')}")
    for ep in endpoints:
        # Handle both detailed format (with config) and simplified format (without config)
        endpoint_name = ep.get('endpoint_name', ep.get('name', ''))
        endpoint_id = ep.get('endpoint_id', ep.get('id', ''))
        
        # Try to get model info from config.served_entities if available
        config = ep.get('config', {})
        served_entities = config.get('served_entities', [])
        model_name = served_entities[0].get('entity_name', '') if served_entities else ''
        model_version_raw = served_entities[0].get('entity_version', '') if served_entities else ''
        model_version = str(model_version_raw) if model_version_raw else ''
        
        # Get state - handle both string and dict formats
        state_value = ep.get('state', '')
        if isinstance(state_value, dict):
            state_value = state_value.get('config_update', '')
        
        # Use helper function to convert timestamp
        creation_timestamp = convert_timestamp(ep.get('creation_timestamp'))
        
        # Ensure all string fields are actually strings
        serving_ep_rows.append(Row(
            workspace_id=str(ws.get('workspace_id', '')),
            scan_id=str(cur_scan_id),
            endpoint_name=str(endpoint_name),
            endpoint_id=str(endpoint_id),
            model_name=str(model_name),
            model_version=model_version,
            state=str(state_value),
            creator=str(ep.get('creator', '') if ep.get('creator') is not None else ''),
            creation_timestamp=creation_timestamp
        ))

serving_ep_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("endpoint_name", StringType(), False),
    StructField("endpoint_id", StringType(), True),
    StructField("model_name", StringType(), True),
    StructField("model_version", StringType(), True),
    StructField("state", StringType(), True),
    StructField("creator", StringType(), True),
    StructField("creation_timestamp", LongType(), True)
])

serving_ep_df = spark.createDataFrame(serving_ep_rows, schema=serving_ep_schema)
print(f"DEBUG: Inserting {serving_ep_df.count()} serving endpoint rows")
# Convert Unix timestamps (seconds) to timestamp type
serving_ep_df = serving_ep_df.withColumn("creation_timestamp", from_unixtime(col("creation_timestamp")).cast(TimestampType()))
serving_ep_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_serving_endpoints")

# Insert Alerts Details
alert_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    alerts = artifacts.get('workspace_objects', {}).get('alerts', [])
    print(f"DEBUG: Found {len(alerts)} alerts in workspace {ws.get('workspace_id', '')}")
    for alert in alerts:
        alert_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            alert_id=str(alert.get('alert_id', '')),
            alert_name=alert.get('display_name', ''),
            query_id=alert.get('query_id', ''),
            state=alert.get('state', ''),
            created_by=alert.get('owner_user_name', '')
        ))

alert_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("alert_id", StringType(), False),
    StructField("alert_name", StringType(), True),
    StructField("query_id", StringType(), True),
    StructField("state", StringType(), True),
    StructField("created_by", StringType(), True)
])

alert_df = spark.createDataFrame(alert_rows, schema=alert_schema)
print(f"DEBUG: Inserting {alert_df.count()} alert rows")
alert_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_alerts")

# Insert Genie Spaces Details
genie_rows = []
for ws in results.get('workspaces', []):
    artifacts = ws.get('artifacts', {})
    genie_spaces = artifacts.get('workspace_objects', {}).get('genie_spaces', [])
    print(f"DEBUG: Found {len(genie_spaces)} genie spaces in workspace {ws.get('workspace_id', '')}")
    for space in genie_spaces:
        print(f"DEBUG: Genie space - space_id: {space.get('space_id')}, title: {space.get('title')}")
        genie_rows.append(Row(
            workspace_id=ws.get('workspace_id', ''),
            scan_id=cur_scan_id,
            space_id=str(space.get('space_id', '')),
            space_name=space.get('title', ''),
            description=space.get('description', ''),
            created_by=space.get('created_by', '')
        ))

genie_schema = StructType([
    StructField("workspace_id", StringType(), False),
    StructField("scan_id", StringType(), False),
    StructField("space_id", StringType(), False),
    StructField("space_name", StringType(), True),
    StructField("description", StringType(), True),
    StructField("created_by", StringType(), True)
])

genie_df = spark.createDataFrame(genie_rows, schema=genie_schema)
print(f"DEBUG: Inserting {genie_df.count()} genie space rows")
genie_df.write.mode("append").saveAsTable(f"{discovery_catalog}.catalog_inventory.workspace_scan_genie_spaces")