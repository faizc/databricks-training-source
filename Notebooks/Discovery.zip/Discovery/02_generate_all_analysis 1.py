# Databricks notebook source
# MAGIC %md
# MAGIC ## Configuration
# MAGIC
# MAGIC **IMPORTANT:** Update the paths in widget to match your environment.

# COMMAND ----------

# dbutils.widgets.removeAll()   # reset any leftover widgets from previous runs
dbutils.widgets.dropdown(
    name    = "confirm_insert",
    defaultValue = "No",
    choices = ["No", "Yes"],
    label   = "Save analysis to Delta Tables?"
)
dbutils.widgets.text(
    name         = "RULES_PATH",
    defaultValue = "/Volumes/dbscannercatalog/catalog_volume/adbscanvol/script/analyzer_rules.json",
    label        = "Rule File"
)
# dbutils.widgets.text(
#     name         = "DISCOVERY_OUTPUT",
#     defaultValue = "/Volumes/ext_nyc_cat_ci/etlschema/etlvolume/script/analyzer_rules.json",
#     label        = "DISCOVERY OUTPUT"
# )
dbutils.widgets.text(
    name         = "DISCOVERY_OUTPUT",
    defaultValue = "/Volumes/dbscannercatalog/catalog_volume/adbscanvol/out/discovery",
    label        = "DISCOVERY OUTPUT"
)
dbutils.widgets.text(
    name         = "ANALYSIS_OUTPUT",
    defaultValue = "/Volumes/dbscannercatalog/catalog_volume/adbscanvol/out/analysis",
    label        = "ANALYSIS OUTPUT"
)
dbutils.widgets.text(
    name         = "_CATALOG",
    defaultValue = "ext_nyc_cat_ci",
    label        = "ANALYSIS Result Catalog"
)
dbutils.widgets.text(
    name         = "_SCHEMA",
    defaultValue = "catalog_inventory",
    label        = "ANALYSIS Result Schema"
)
dbutils.widgets.text(
    name         = "Lookback_Days",
    defaultValue = "30",
    label        = "LOOKBACK_DAYS"
)

# COMMAND ----------

# Install required packages
# --no-deps: pandas and numpy are already provided by Databricks Runtime - do not reinstall them
%pip install --force-reinstall --no-deps --no-cache-dir /Volumes/dbscannercatalog/catalog_volume/adbscanvol/script/databricks_toolkit-3.0.2-py3-none-any.whl
# openpyxl is NOT bundled in Databricks Runtime - must be installed explicitly
%pip install openpyxl --quiet


# COMMAND ----------

# Restart Python to load the newly installed package
dbutils.library.restartPython()

# COMMAND ----------

import os
import shutil
from datetime import datetime

# Import analysis components
from databricks_toolkit.analysis import (
    ClusterUtilizationAnalyzer,
    QueryUtilizationAnalyzer,
    SecurityAnalyzer,
    SparkJobOptimizerAnalyzer,
    SparkRecommendationEngine,
    ConfigurationAnalyzer,
    JobExecutionAnalyzer,
    UnityCatalogGovernanceAnalyzer,
    DLTPipelineAnalyzer,
    CostAttributionAnalyzer,
    run_consolidated_cluster_analysis
)
from databricks_toolkit.models.spark_optimizer_models import ScanResult as SparkScanResult

# ===================================================================
# CONFIGURATION - Update these paths
# ===================================================================
RULES_PATH      = dbutils.widgets.get("RULES_PATH")
# Discovery output path (from discovery notebook)
DISCOVERY_OUTPUT = dbutils.widgets.get("DISCOVERY_OUTPUT")

# Analysis output directory (where Excel reports will be saved)
ANALYSIS_OUTPUT = dbutils.widgets.get("ANALYSIS_OUTPUT")

# Local temporary directory for analysis processing
# Use a unique timestamp-based directory to avoid permission conflicts
import time
timestamp = int(time.time())
ANALYSIS_TEMP_DIR = f"/tmp/workspace_analysis_{timestamp}"

Lookback_Days = int(dbutils.widgets.get("Lookback_Days"))

print("✓ Configuration loaded")
print(f"  Discovery Input: {DISCOVERY_OUTPUT}")
print(f"  Rules File Path: {RULES_PATH}")
print(f"  Analysis Output: {ANALYSIS_OUTPUT}")
print(f"  Temp Directory: {ANALYSIS_TEMP_DIR}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Detect Data Paths
# MAGIC
# MAGIC Automatically find cluster, query, jobs, and security data.

# COMMAND ----------

def find_data_paths(discovery_root):
    """
    Find all data paths from discovery output.
    Handles both workspace-specific folders (ws_*) and direct structure.
    Each analyzer knows which subdirectory to look in under the workspace folder.
    """
    paths = {
        'cluster_input': None,
        'query_input': None,
        'jobs_input': None,
        'security_input': None,
        'spark_optimizer_input': None,
        'clusters_metadata': None,  # Discovery metadata for configuration analysis
        'jobs_metadata': None,      # Discovery metadata for configuration analysis
        # Enhanced utilization paths
        'job_execution_input': None,     # Job run history, task runs, failure rates
        'uc_governance_input': None,     # Unity Catalog governance data
        'dlt_pipeline_input': None,      # DLT pipeline history (or config fallback)
        'cost_attribution_input': None,  # Cost by cluster/job
    }
    
    try:
        # Convert path to local for os operations
        local_discovery_root = discovery_root.replace('/dbfs/', '/').replace('dbfs:', '')
        if not local_discovery_root.startswith('/') and not local_discovery_root.startswith('/Volumes/'):
            local_discovery_root = '/dbfs' + local_discovery_root
            
        if os.path.exists(local_discovery_root):
            workspace_folders = [d for d in os.listdir(local_discovery_root) 
                               if os.path.isdir(os.path.join(local_discovery_root, d)) and d.startswith('ws_')]
            
            if workspace_folders:
                # Workspace folder structure
                workspace_folder = os.path.join(local_discovery_root, workspace_folders[0])
                paths['cluster_input'] = os.path.join(workspace_folder, 'utilization', 'cluster')
                paths['query_input'] = os.path.join(workspace_folder, 'utilization', 'query')
                paths['jobs_input'] = os.path.join(workspace_folder, 'jobs', 'json')
                
                # Check for security data (json preferred, csv fallback)
                for folder_type in ['json', 'csv']:
                    security_path = os.path.join(workspace_folder, 'security', folder_type)
                    if os.path.exists(security_path):
                        security_files = [f for f in os.listdir(security_path) 
                                        if f.endswith(('.json', '.csv'))]
                        if security_files:
                            paths['security_input'] = os.path.join(security_path, security_files[0])
                            break

                # Check for spark job optimizer data (json preferred, csv fallback)
                for folder_type in ['json', 'csv']:
                    sjo_path = os.path.join(workspace_folder, 'spark_job_optimizer', folder_type)
                    if os.path.exists(sjo_path):
                        sjo_files = sorted([f for f in os.listdir(sjo_path)
                                            if f.endswith(('.json', '.csv'))])
                        if sjo_files:
                            paths['spark_optimizer_input'] = os.path.join(sjo_path, sjo_files[0])
                            break
                
                # Check for discovery metadata (for configuration analysis)
                clusters_meta_path = os.path.join(workspace_folder, 'clusters', 'json')
                if os.path.exists(clusters_meta_path):
                    paths['clusters_metadata'] = clusters_meta_path
                
                jobs_meta_path = os.path.join(workspace_folder, 'jobs', 'json')
                if os.path.exists(jobs_meta_path):
                    paths['jobs_metadata'] = jobs_meta_path
                
                # Check for enhanced utilization data
                job_exec_path = os.path.join(workspace_folder, 'utilization', 'jobs')
                if os.path.exists(job_exec_path):
                    paths['job_execution_input'] = job_exec_path
                
                uc_gov_path = os.path.join(workspace_folder, 'utilization', 'unity_catalog')
                if os.path.exists(uc_gov_path):
                    paths['uc_governance_input'] = uc_gov_path
                
                # DLT: prefer execution history, fall back to pipeline config JSON
                dlt_path = os.path.join(workspace_folder, 'utilization', 'dlt')
                if os.path.exists(dlt_path):
                    paths['dlt_pipeline_input'] = dlt_path
                else:
                    pipelines_json_path = os.path.join(workspace_folder, 'pipelines', 'json')
                    if os.path.exists(pipelines_json_path) and any(
                        f.endswith('.json') for f in os.listdir(pipelines_json_path)
                    ):
                        paths['dlt_pipeline_input'] = pipelines_json_path
                
                cost_path = os.path.join(workspace_folder, 'utilization', 'cost')
                if os.path.exists(cost_path):
                    paths['cost_attribution_input'] = cost_path
            else:
                # Direct structure
                paths['cluster_input'] = os.path.join(local_discovery_root, 'utilization', 'cluster')
                paths['query_input'] = os.path.join(local_discovery_root, 'utilization', 'query')
                paths['jobs_input'] = os.path.join(local_discovery_root, 'jobs', 'json')
                
                # Check for security data
                for folder_type in ['json', 'csv']:
                    security_path = os.path.join(local_discovery_root, 'security', folder_type)
                    if os.path.exists(security_path):
                        security_files = [f for f in os.listdir(security_path) 
                                        if f.endswith(('.json', '.csv'))]
                        if security_files:
                            paths['security_input'] = os.path.join(security_path, security_files[0])
                            break

                # Check for spark job optimizer data (json preferred, csv fallback)
                for folder_type in ['json', 'csv']:
                    sjo_path = os.path.join(local_discovery_root, 'spark_job_optimizer', folder_type)
                    if os.path.exists(sjo_path):
                        sjo_files = sorted([f for f in os.listdir(sjo_path)
                                            if f.endswith(('.json', '.csv'))])
                        if sjo_files:
                            paths['spark_optimizer_input'] = os.path.join(sjo_path, sjo_files[0])
                            break
                
                # Check for discovery metadata (for configuration analysis)
                clusters_meta_path = os.path.join(local_discovery_root, 'clusters', 'json')
                if os.path.exists(clusters_meta_path):
                    paths['clusters_metadata'] = clusters_meta_path
                
                jobs_meta_path = os.path.join(local_discovery_root, 'jobs', 'json')
                if os.path.exists(jobs_meta_path):
                    paths['jobs_metadata'] = jobs_meta_path
                
                # Check for enhanced utilization data
                job_exec_path = os.path.join(local_discovery_root, 'utilization', 'jobs')
                if os.path.exists(job_exec_path):
                    paths['job_execution_input'] = job_exec_path
                
                uc_gov_path = os.path.join(local_discovery_root, 'utilization', 'unity_catalog')
                if os.path.exists(uc_gov_path):
                    paths['uc_governance_input'] = uc_gov_path
                
                # DLT: prefer execution history, fall back to pipeline config JSON
                dlt_path = os.path.join(local_discovery_root, 'utilization', 'dlt')
                if os.path.exists(dlt_path):
                    paths['dlt_pipeline_input'] = dlt_path
                else:
                    pipelines_json_path = os.path.join(local_discovery_root, 'pipelines', 'json')
                    if os.path.exists(pipelines_json_path) and any(
                        f.endswith('.json') for f in os.listdir(pipelines_json_path)
                    ):
                        paths['dlt_pipeline_input'] = pipelines_json_path
                
                cost_path = os.path.join(local_discovery_root, 'utilization', 'cost')
                if os.path.exists(cost_path):
                    paths['cost_attribution_input'] = cost_path
    except Exception as e:
        print(f"Error determining paths: {e}")
    
    return paths

# Find data paths
data_paths = find_data_paths(DISCOVERY_OUTPUT)

print("\nData paths identified:")
print(f"  📊 Cluster: {data_paths['cluster_input']}")
print(f"     Exists: {os.path.exists(data_paths['cluster_input']) if data_paths['cluster_input'] else False}")
print(f"  📊 Security: {data_paths['security_input']}")
print(f"  📊 Query: {data_paths['query_input']}")
print(f"     Exists: {os.path.exists(data_paths['query_input']) if data_paths['query_input'] else False}")
print(f"  📊 Spark Job Optimizer: {data_paths['spark_optimizer_input']}")
print(f"  📊 Clusters Metadata (Discovery): {data_paths['clusters_metadata']}")
print(f"     Exists: {os.path.exists(data_paths['clusters_metadata']) if data_paths['clusters_metadata'] else False}")
print(f"  📊 Jobs Metadata (Discovery): {data_paths['jobs_metadata']}")
print(f"     Exists: {os.path.exists(data_paths['jobs_metadata']) if data_paths['jobs_metadata'] else False}")
print(f"  📊 Job Execution (Enhanced): {data_paths['job_execution_input']}")
print(f"     Exists: {os.path.exists(data_paths['job_execution_input']) if data_paths['job_execution_input'] else False}")
print(f"  📊 UC Governance (Enhanced): {data_paths['uc_governance_input']}")
print(f"     Exists: {os.path.exists(data_paths['uc_governance_input']) if data_paths['uc_governance_input'] else False}")
print(f"  📊 DLT Pipeline (Enhanced): {data_paths['dlt_pipeline_input']}")
print(f"     Exists: {os.path.exists(data_paths['dlt_pipeline_input']) if data_paths['dlt_pipeline_input'] else False}")
print(f"  📊 Cost Attribution (Enhanced): {data_paths['cost_attribution_input']}")
print(f"     Exists: {os.path.exists(data_paths['cost_attribution_input']) if data_paths['cost_attribution_input'] else False}")

# Comprehensive data availability check
print("\n" + "="*80)
print("DATA AVAILABILITY ASSESSMENT")
print("="*80)

available_analyzers = []
missing_analyzers = []

# Check each analyzer's data requirements
if data_paths['cluster_input'] and os.path.exists(data_paths['cluster_input']):
    available_analyzers.append('✅ Cluster Analysis (utilization, recommendations)')
else:
    missing_analyzers.append('❌ Cluster Analysis - Missing: utilization/cluster folder')

if data_paths['jobs_input'] and os.path.exists(data_paths['jobs_input']):
    available_analyzers.append('✅ Job Analysis (configuration, runs, patterns)')
else:
    missing_analyzers.append('❌ Job Analysis - Missing: jobs/json folder')

if data_paths['query_input'] and os.path.exists(data_paths['query_input']):
    available_analyzers.append('✅ Query Analysis (SQL Warehouse performance)')
else:
    missing_analyzers.append('⚠️  Query Analysis - Missing: utilization/query folder (optional)')

if data_paths['security_input'] and os.path.exists(data_paths['security_input']):
    available_analyzers.append('✅ Security Analysis (posture assessment)')
else:
    missing_analyzers.append('⚠️  Security Analysis - Missing: security data (optional)')


# COMMAND ----------

# MAGIC %md
# MAGIC ## Run Complete Analysis
# MAGIC
# MAGIC This cell executes ALL analyzers and generates comprehensive reports:
# MAGIC 1. **Cluster Analysis** - 7 consolidated analyzers (utilization, network, RI, worker nodes, single-node, autoscaling, recommendations)
# MAGIC 2. **Job Analysis** - Job configuration and execution patterns
# MAGIC 3. **Query Analysis** - SQL Warehouse query performance (if data available)
# MAGIC 4. **Security Analysis** - Comprehensive security posture assessment
# MAGIC 5. **Spark Job Optimizer Analysis** - Data skew, shuffle spill, small files, long-running jobs, failed tasks, Delta issues (if data available)
# MAGIC
# MAGIC All reports are saved as Excel files in the output directory.
# MAGIC

# COMMAND ----------

print("="*80)
print("RUNNING COMPREHENSIVE WORKSPACE ANALYSIS")
print("="*80)
print(f"\nThis will generate:")
print(f"  1. Cluster Analysis (7 analyzers consolidated)")
print(f"  2. Job Analysis")
print(f"  3. Query Analysis (if data available)")
print(f"  4. Security Analysis (if data available)")
print(f"  5. Spark Job Optimizer Analysis (if data available)")
print(f"  6. Configuration Analysis (if discovery metadata available)")
print(f"\nOutput: {ANALYSIS_OUTPUT}")
print("="*80 + "\n")

# Create temporary directory with proper cleanup
temp_dir = os.path.join(ANALYSIS_TEMP_DIR, 'comprehensive')

# Clean up any existing temp directory first
if os.path.exists(ANALYSIS_TEMP_DIR):
    try:
        shutil.rmtree(ANALYSIS_TEMP_DIR)
        print(f"✓ Cleaned up existing temp directory")
    except Exception as e:
        print(f"⚠️  Warning: Could not clean existing temp dir: {e}")

# Create fresh temp directory
try:
    os.makedirs(temp_dir, mode=0o777, exist_ok=True)
    print(f"✓ Created temp directory: {temp_dir}")
except Exception as e:
    print(f"❌ Error creating temp directory: {e}")
    # Fallback to a simpler path
    temp_dir = f"/tmp/analysis_{timestamp}"
    os.makedirs(temp_dir, mode=0o777, exist_ok=True)
    print(f"✓ Using fallback temp directory: {temp_dir}")

# Determine output path based on storage type
if ANALYSIS_OUTPUT.startswith('/Volumes/'):
    output_path = ANALYSIS_OUTPUT
elif ANALYSIS_OUTPUT.startswith('/dbfs/') or ANALYSIS_OUTPUT.startswith('dbfs:/'):
    output_path = ANALYSIS_OUTPUT.replace('dbfs:/', '/dbfs/')
    if not output_path.startswith('/dbfs'):
        output_path = '/dbfs' + output_path
else:
    output_path = '/dbfs' + ANALYSIS_OUTPUT

os.makedirs(output_path, exist_ok=True)

reports_generated = []
initial_job_report = None  # Track the initial job report to delete later if enhanced
sjo_scan_result   = None   # declared here so the preview and Delta cells can reference it
sjo_analyzer      = SparkJobOptimizerAnalyzer({})
cluster_results   = {}      # Initialize to avoid reference errors in later cells

try:
    # =========================================================================
    # 1. CLUSTER + JOB ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 1/6: RUNNING CLUSTER + JOB ANALYSIS")
    print(f"{'='*80}\n")
    
    # Check if we have any data to analyze
    has_cluster = data_paths['cluster_input'] and os.path.exists(data_paths['cluster_input'])
    has_jobs = data_paths['jobs_input'] and os.path.exists(data_paths['jobs_input'])
    
    if has_cluster and has_jobs:
        # Both cluster and job data available - use consolidated analysis
        cluster_results = run_consolidated_cluster_analysis(
            cluster_input_path=data_paths['cluster_input'],
            output_dir=temp_dir,
            job_input_path=data_paths['jobs_input'],
            rules_path=RULES_PATH
        )
        
        # Copy cluster report
        if cluster_results.get('cluster_output_file') and os.path.exists(cluster_results['cluster_output_file']):
            cluster_dst = os.path.join(output_path, os.path.basename(cluster_results['cluster_output_file']))
            shutil.copy2(cluster_results['cluster_output_file'], cluster_dst)
            reports_generated.append(f"Cluster Analysis: {os.path.basename(cluster_results['cluster_output_file'])}")
            print(f"\n✓ Cluster report saved: {os.path.basename(cluster_results['cluster_output_file'])}")
        
        # Copy job report (will be enhanced later with Task Skew data if Spark optimizer runs)
        if cluster_results.get('job_output_file') and os.path.exists(cluster_results['job_output_file']):
            job_dst = os.path.join(output_path, os.path.basename(cluster_results['job_output_file']))
            shutil.copy2(cluster_results['job_output_file'], job_dst)
            initial_job_report = job_dst  # Track this so we can delete it later if enhanced
            reports_generated.append(f"Job Analysis: {os.path.basename(cluster_results['job_output_file'])}")
            print(f"✓ Job report saved: {os.path.basename(cluster_results['job_output_file'])}")
            
    elif has_cluster:
        # Only cluster data - run cluster-only analysis
        print("ℹ️  Job data not found - running cluster analysis only")
        cluster_results = run_consolidated_cluster_analysis(
            cluster_input_path=data_paths['cluster_input'],
            output_dir=temp_dir,
            job_input_path=None,
            rules_path=RULES_PATH
        )
        
        # Copy cluster report
        if cluster_results.get('cluster_output_file') and os.path.exists(cluster_results['cluster_output_file']):
            cluster_dst = os.path.join(output_path, os.path.basename(cluster_results['cluster_output_file']))
            shutil.copy2(cluster_results['cluster_output_file'], cluster_dst)
            reports_generated.append(f"Cluster Analysis: {os.path.basename(cluster_results['cluster_output_file'])}")
            print(f"\n✓ Cluster report saved: {os.path.basename(cluster_results['cluster_output_file'])}")
            
    elif has_jobs:
        # Only job data - run job-only analysis
        print("ℹ️  Cluster data not found - running job analysis only")
        try:
            from databricks_toolkit.analysis.job_analyzer import JobAnalyzer
            job_analyzer = JobAnalyzer(data_paths['jobs_input'], temp_dir)
            
            # Check if Spark optimizer report already exists (from previous run)
            spark_opt_path = None
            if data_paths.get('spark_optimizer_input'):
                _ws_id_check = data_paths.get('spark_optimizer_input', '')
                if 'adb-' in _ws_id_check or 'workspace' in _ws_id_check:
                    import re
                    ws_match = re.search(r'adb-?(\d+)', _ws_id_check)
                    if ws_match:
                        _ws_id = ws_match.group(1)
                        spark_opt_path = os.path.join(output_path, f"Spark_Job_Optimizer_{_ws_id}.xlsx")
                        if not os.path.exists(spark_opt_path):
                            spark_opt_path = None
            
            job_results = job_analyzer.analyze(spark_optimizer_excel_path=spark_opt_path)
            
            if job_results.get('output_file') and os.path.exists(job_results['output_file']):
                job_dst = os.path.join(output_path, os.path.basename(job_results['output_file']))
                shutil.copy2(job_results['output_file'], job_dst)
                initial_job_report = job_dst  # Track this
                suffix = ' (with Task Skew)' if spark_opt_path else ''
                reports_generated.append(f"Job Analysis{suffix}: {os.path.basename(job_results['output_file'])}")
                print(f"\n✓ Job report{suffix} saved: {os.path.basename(job_results['output_file'])}")
                
                # Store results for later cells
                cluster_results = {'job_stats': job_results}
        except Exception as e:
            print(f"⚠️  Job analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Cluster and Job data not found - skipping both analyses")
        print("   This is expected if discovery did not collect utilization or job data")
    
    # =========================================================================
    # 2. QUERY ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 2/6: RUNNING QUERY ANALYSIS")
    print(f"{'='*80}\n")
    
    if data_paths['query_input'] and os.path.exists(data_paths['query_input']):
        try:
            query_analyzer = QueryUtilizationAnalyzer(
                input_path=data_paths['query_input'],
                output_dir=temp_dir
            )
            
            query_results = query_analyzer.analyze()
            
            # Copy query report
            if query_results.get('output_file') and os.path.exists(query_results['output_file']):
                query_dst = os.path.join(output_path, os.path.basename(query_results['output_file']))
                shutil.copy2(query_results['output_file'], query_dst)
                reports_generated.append(f"Query Analysis: {os.path.basename(query_results['output_file'])}")
                print(f"\n✓ Query report saved: {os.path.basename(query_results['output_file'])}")
        except FileNotFoundError as e:
            print(f"⚠️  Query data not found: {e}")
            print("   This is normal if no SQL Warehouses were active during discovery")
        except Exception as e:
            print(f"⚠️  Query analysis skipped: {e}")
    else:
        print("⚠️  Query data not found - skipping query analysis")
        print("   This is normal if no SQL Warehouses were active during discovery")
    
    # =========================================================================
    # 3. SECURITY ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 3/6: RUNNING SECURITY ANALYSIS")
    print(f"{'='*80}\n")
    
    if data_paths['security_input'] and os.path.exists(data_paths['security_input']):
        try:
            print(f"✓ Security data located: {data_paths['security_input']}")
            
            security_analyzer = SecurityAnalyzer(
                discovery_path=data_paths['security_input'],
                output_dir=temp_dir
            )
            
            security_results = security_analyzer.analyze()
            
            # Copy security report - handle different return structures
            output_file = None
            
            # Debug: print what we got back
            print(f"\nDebug - security_results keys: {security_results.keys()}")
            
            # Try different keys and structures
            if 'output_files' in security_results:
                result_data = security_results['output_files']
                if isinstance(result_data, dict):
                    output_file = result_data.get('xlsx') or result_data.get('excel') or result_data.get('file')
                elif isinstance(result_data, str):
                    output_file = result_data
            elif 'output_file' in security_results:
                output_file = security_results['output_file']
            
            # If still no file, try to find any xlsx file in temp_dir
            if not output_file:
                print("Debug - Searching temp directory for security report...")
                for file in os.listdir(temp_dir):
                    if file.startswith('Security_Analysis') and file.endswith('.xlsx'):
                        output_file = os.path.join(temp_dir, file)
                        print(f"Debug - Found security report: {output_file}")
                        break
            
            if output_file and isinstance(output_file, str) and os.path.exists(output_file):
                security_dst = os.path.join(output_path, os.path.basename(output_file))
                shutil.copy2(output_file, security_dst)
                reports_generated.append(f"Security Analysis: {os.path.basename(output_file)}")
                print(f"\n✓ Security report saved: {os.path.basename(output_file)}")
            else:
                print(f"⚠️  Security report file not found")
                print(f"   Result structure: {security_results}")
        except Exception as e:
            print(f"⚠️  Security analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Security data not found - skipping security analysis")
        print("   Run discovery with scan_type='deep' to collect security data")

    # =========================================================================
    # 4. SPARK JOB OPTIMIZER ANALYSIS
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 4/6: RUNNING SPARK JOB OPTIMIZER ANALYSIS")
    print(f"{'='*80}\n")

    if data_paths.get('spark_optimizer_input') and os.path.exists(data_paths['spark_optimizer_input']):
        try:
            import json as _json
            import pandas as pd
            from datetime import datetime as _dt

            _sjo_file = data_paths['spark_optimizer_input']
            _sjo_ext  = os.path.splitext(_sjo_file)[1].lower()
            print(f"✓ Spark optimizer data: {_sjo_file}")

            def _to_df(records):
                return pd.DataFrame(records) if records else pd.DataFrame()

            if _sjo_ext == '.json':
                with open(_sjo_file, encoding='utf-8') as _fh:
                    _raw = _json.load(_fh)
                # scanner output: {'metadata': ..., 'spark_job_optimizer': {...}}
                _sjo_data = _raw.get('spark_job_optimizer', _raw)
                _summary  = _sjo_data.get('summary', {})

            elif _sjo_ext == '.csv':
                _csv_df   = pd.read_csv(_sjo_file)
                _ws_id    = str(_csv_df['workspace_id'].iloc[0])   if 'workspace_id'   in _csv_df.columns and len(_csv_df) else ''
                _ws_name  = str(_csv_df['workspace_name'].iloc[0]) if 'workspace_name' in _csv_df.columns and len(_csv_df) else ''
                _ts_str   = str(_csv_df['scan_timestamp'].iloc[0]) if 'scan_timestamp' in _csv_df.columns and len(_csv_df) else ''
                _lb       = int(_csv_df['lookback_days'].iloc[0])  if 'lookback_days'  in _csv_df.columns and len(_csv_df) else Lookback_Days
                _base_cols = {'workspace_id', 'workspace_name', 'scan_timestamp', 'lookback_days', 'category'}
                # flatten_for_csv uses category column to tag each row
                _cat_key_map = {
                    'data_skew':            'skewed_jobs',
                    'shuffle_spill':        'shuffle_spill_jobs',
                    'broadcast_candidates': 'broadcast_candidates',
                    'long_running_jobs':    'long_running_jobs',
                    'failed_tasks':         'failed_tasks',
                }
                _sjo_data = {'summary': {
                    'workspace_id': _ws_id, 'workspace_name': _ws_name,
                    'scan_timestamp': _ts_str, 'lookback_days':Lookback_Days,
                }}
                for _cat, _key in _cat_key_map.items():
                    _sub = _csv_df[_csv_df['category'] == _cat] if 'category' in _csv_df.columns else pd.DataFrame()
                    _sjo_data[_key] = _sub.drop(
                        columns=[c for c in _base_cols if c in _sub.columns], errors='ignore'
                    ).to_dict(orient='records')
                _summary = _sjo_data['summary']
            else:
                raise ValueError(f"Unsupported spark optimizer file format: {_sjo_ext}")

            # Reconstruct ScanResult from saved dict
            try:
                _scan_ts = _dt.fromisoformat(str(_summary.get('scan_timestamp', '')))
            except Exception:
                _scan_ts = _dt.now()

            sjo_scan_result = SparkScanResult(
                workspace_id         = _summary.get('workspace_id',   ''),
                workspace_name       = _summary.get('workspace_name', ''),
                scan_timestamp       = _scan_ts,
                scan_mode            = _summary.get('scan_mode',      'deep'),
                lookback_days        = int(_summary.get('lookback_days', Lookback_Days)),
                skewed_jobs          = _to_df(_sjo_data.get('skewed_jobs',          [])),
                shuffle_spill_jobs   = _to_df(_sjo_data.get('shuffle_spill_jobs',   [])),
                broadcast_candidates = _to_df(_sjo_data.get('broadcast_candidates', [])),
                long_running_jobs    = _to_df(_sjo_data.get('long_running_jobs',    [])),
                failed_tasks         = _to_df(_sjo_data.get('failed_tasks',         [])),
            )
            print(f"  Total findings loaded: {sjo_scan_result.total_findings}")

            # Generate Excel report
            _ws_slug      = (sjo_scan_result.workspace_id or 'workspace').replace('/', '_')
            _sjo_rpt_name = f"Spark_Job_Optimizer_{_ws_slug}.xlsx"
            _sjo_rpt_tmp  = os.path.join(temp_dir, _sjo_rpt_name)
            sjo_analyzer.generate_report(sjo_scan_result, _sjo_rpt_tmp)

            if os.path.exists(_sjo_rpt_tmp):
                _sjo_rpt_final = os.path.join(output_path, _sjo_rpt_name)
                shutil.copy2(_sjo_rpt_tmp, _sjo_rpt_final)
                reports_generated.append(f"Spark Job Optimizer: {_sjo_rpt_name}")
                print(f"✓ Spark Job Optimizer report saved: {_sjo_rpt_name}")
                
                # If we already ran job analysis without skew data, re-run it now with skew
                if has_jobs and os.path.exists(_sjo_rpt_final) and initial_job_report:
                    print(f"\n{'='*80}")
                    print("ENHANCING JOB ANALYSIS WITH TASK SKEW DATA")
                    print(f"{'='*80}\n")
                    try:
                        from databricks_toolkit.analysis.job_analyzer import JobAnalyzer
                        job_analyzer_enhanced = JobAnalyzer(data_paths['jobs_input'], temp_dir)
                        job_results_enhanced = job_analyzer_enhanced.analyze(spark_optimizer_excel_path=_sjo_rpt_final)
                        
                        if job_results_enhanced.get('output_file') and os.path.exists(job_results_enhanced['output_file']):
                            # Delete the old job report without skew data
                            if os.path.exists(initial_job_report):
                                try:
                                    os.remove(initial_job_report)
                                    print(f"✓ Removed initial job report (without skew): {os.path.basename(initial_job_report)}")
                                except Exception as del_err:
                                    print(f"⚠️  Could not delete old job report: {del_err}")
                            
                            # Copy the enhanced job report
                            job_dst = os.path.join(output_path, os.path.basename(job_results_enhanced['output_file']))
                            shutil.copy2(job_results_enhanced['output_file'], job_dst)
                            
                            # Update reports list (remove old, add new)
                            reports_generated = [r for r in reports_generated if not r.startswith('Job Analysis:')]
                            reports_generated.append(f"Job Analysis (with Task Skew): {os.path.basename(job_results_enhanced['output_file'])}")
                            print(f"✓ Enhanced Job report with Task Skew data saved: {os.path.basename(job_results_enhanced['output_file'])}")
                    except Exception as e:
                        print(f"⚠️  Could not enhance job analysis with skew data: {e}")
                        import traceback
                        traceback.print_exc()

        except Exception as e:
            print(f"⚠️  Spark Job Optimizer analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Spark optimizer data not found — skipping")
        print("   Enable spark_job_optimizer in config.json and re-run discovery")

    # =========================================================================
    # 5. CONFIGURATION ANALYSIS (Discovery Metadata)
    # =========================================================================
    print(f"\n{'='*80}")
    print("STEP 5/6: RUNNING CONFIGURATION ANALYSIS (Discovery Metadata)")
    print(f"{'='*80}\n")
    
    if (data_paths.get('clusters_metadata') and os.path.exists(data_paths['clusters_metadata']) and
        data_paths.get('jobs_metadata') and os.path.exists(data_paths['jobs_metadata'])):
        try:
            print(f"✓ Clusters metadata: {data_paths['clusters_metadata']}")
            print(f"✓ Jobs metadata: {data_paths['jobs_metadata']}")
            
            config_analyzer = ConfigurationAnalyzer(
                clusters_json_path=data_paths['clusters_metadata'],
                jobs_json_path=data_paths['jobs_metadata'],
                output_dir=temp_dir
            )
            
            config_results = config_analyzer.analyze()
            
            # Copy configuration analysis report
            if config_results.get('output_file') and os.path.exists(config_results['output_file']):
                config_dst = os.path.join(output_path, os.path.basename(config_results['output_file']))
                shutil.copy2(config_results['output_file'], config_dst)
                reports_generated.append(f"Configuration Analysis: {os.path.basename(config_results['output_file'])}")
                print(f"\n✓ Configuration Analysis report saved: {os.path.basename(config_results['output_file'])}")
                
                # Print key findings
                summary = config_results.get('summary', {})
                print(f"\n  📊 Key Findings:")
                print(f"     - Cost Opportunities: {summary.get('cost_opportunities_count', 0)}")
                print(f"     - Governance Issues: {summary.get('governance_issues_count', 0)}")
                print(f"     - Reliability Risks: {summary.get('reliability_risks_count', 0)}")
                print(f"     - Operational Issues: {summary.get('operational_issues_count', 0)}")
        except Exception as e:
            print(f"⚠️  Configuration analysis failed: {e}")
            import traceback
            traceback.print_exc()
    else:
        print("⚠️  Discovery metadata not found - skipping configuration analysis")
        print("   This analysis requires clusters/json and jobs/json folders from discovery")

    # =========================================================================
    # 6. ENHANCED UTILIZATION ANALYSIS 
    # =========================================================================
    # Note: Enhanced utilization analysis (Job Execution, UC Governance, DLT, Cost)
    # is run separately in the dedicated cell below after the main preview section.
    print(f"\n{'='*80}")
    print("STEP 6/6: Enhanced Utilization Analysis")
    print("   (Run separately in dedicated cell after preview)")
    print(f"{'='*80}\n")
    
    # =========================================================================
    # SUMMARY
    # =========================================================================
    print(f"\n{'='*80}")
    print("✓ COMPREHENSIVE ANALYSIS COMPLETE")
    print(f"{'='*80}\n")
    print(f"Generated {len(reports_generated)} report(s):\n")
    for report in reports_generated:
        print(f"  📊 {report}")
    print(f"\nAll reports saved to: {ANALYSIS_OUTPUT}")
    print("="*80)

except Exception as e:
    print(f"\n❌ Error during comprehensive analysis: {str(e)}")
    import traceback
    traceback.print_exc()

finally:
    # Clean up temporary files
    try:
        if os.path.exists(ANALYSIS_TEMP_DIR):
            shutil.rmtree(ANALYSIS_TEMP_DIR)
            print(f"\n✓ Cleaned up temporary files")
    except Exception as e:
        print(f"⚠️  Warning: Could not clean up temp files: {e}")

# COMMAND ----------

# import pandas as pd, glob, os

# base = "/Volumes/dbscannercatalog/catalog_volume/adbscanvol/out-bfl/discovery/utilization"
# clu = glob.glob(f"{base}/cluster/*_cluster_utilization.csv")[0]
# jrh = glob.glob(f"{base}/jobs/adb-2870269239375654_job_run_history.csv")[0]

# cdf = pd.read_csv(clu)
# jdf = pd.read_csv(jrh)

# print("RUN-HISTORY columns:", list(jdf.columns))
# print("  has 'start_time'?   ", 'start_time'   in jdf.columns)
# print("  has 'duration_mins'?", 'duration_mins' in jdf.columns)
# print("  has 'job_id'?       ", 'job_id'       in jdf.columns)

# print("\nCLUSTER-CSV has 'job_id'?", 'job_id' in cdf.columns)

# # Job-id overlap test (cause A)
# cl_ids = set(cdf['job_id'].dropna().astype(str)) if 'job_id' in cdf.columns else set()
# jr_ids = set(jdf['job_id'].dropna().astype(str)) if 'job_id' in jdf.columns else set()
# print(f"\ncluster distinct job_ids : {len(cl_ids)}")
# print(f"runhist distinct job_ids : {len(jr_ids)}")
# print(f"overlap                  : {len(cl_ids & jr_ids)}")
# print("sample cluster job_ids:", list(cl_ids)[:5])
# print("sample runhist job_ids:", list(jr_ids)[:5])

# cl_clean = {s[:-2] if s.endswith('.0') else s for s in cl_ids}
# jr_clean = {s[:-2] if s.endswith('.0') else s for s in jr_ids}
# print("overlap after stripping '.0':", len(cl_clean & jr_clean))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Enhanced Utilization Analysis (NEW)
# MAGIC
# MAGIC This section analyzes the new behavioral telemetry data collected from Databricks system tables:
# MAGIC
# MAGIC 1. **Job Execution Analysis** - Job runs, task runs, failure rates, performance insights
# MAGIC 2. **Unity Catalog Governance** - Catalog inventory, stale tables, empty schemas
# MAGIC 3. **DLT Pipeline Analysis** - Delta Live Tables pipeline execution history and failures
# MAGIC 4. **Cost Attribution** - DBU consumption and estimated costs by cluster and job
# MAGIC
# MAGIC **Note:** This data is only available when running discovery with deep scan mode enabled.
# MAGIC

# COMMAND ----------

# -----------------------------------------------------------------------------
# ENHANCED UTILIZATION ANALYSIS (Job Execution, UC Governance, DLT, Cost)
# -----------------------------------------------------------------------------

import re

print("\n" + "=" * 80)
print("RUNNING ENHANCED UTILIZATION ANALYSIS")
print("=" * 80 + "\n")

enhanced_results = {}
excel_sheets = {}
uc_excel_sheets = {}  # Separate dictionary for UC-only sheets
uc_generated = False


def _safe_sheet_name(name: str) -> str:
    # Excel sheet name limit and invalid chars
    invalid = [":", "\\", "/", "?", "*", "[", "]"]
    out = name
    for ch in invalid:
        out = out.replace(ch, "_")
    return out[:31]


def _add_metric_value_sheet(sheet_name, data_dict):
    """Write scalar fields from dict as Metric/Value rows for readability."""
    if not isinstance(data_dict, dict) or not data_dict:
        return

    rows = []
    for k, v in data_dict.items():
        if isinstance(v, (dict, list, tuple, set)):
            continue
        rows.append({"metric": k, "value": v})

    if rows:
        excel_sheets[_safe_sheet_name(sheet_name)] = pd.DataFrame(rows)


def _add_dict_rows_sheet(sheet_name, data_dict, key_col_name="name"):
    """Convert dict or dict-of-dicts to table rows (no raw JSON blobs)."""
    if not isinstance(data_dict, dict) or not data_dict:
        return

    rows = []
    # dict of dicts -> each key becomes row label + merged child fields
    if all(isinstance(v, dict) for v in data_dict.values()):
        for k, v in data_dict.items():
            row = {key_col_name: k}
            row.update(v)
            rows.append(row)
    else:
        # simple dict -> metric/value rows
        for k, v in data_dict.items():
            if isinstance(v, (dict, list, tuple, set)):
                continue
            rows.append({key_col_name: k, "value": v})

    if rows:
        excel_sheets[_safe_sheet_name(sheet_name)] = pd.DataFrame(rows)


def _add_records_sheet(sheet_name, records):
    """Convert list records to DataFrame; supports list[dict] and list[scalar]."""
    if not isinstance(records, list) or len(records) == 0:
        return

    if all(isinstance(x, dict) for x in records):
        df = pd.DataFrame(records)
    else:
        df = pd.DataFrame({"value": records})

    if not df.empty:
        excel_sheets[_safe_sheet_name(sheet_name)] = df


# UC-specific helper functions (add to uc_excel_sheets instead)
def _add_uc_metric_sheet(sheet_name, data_dict):
    if not isinstance(data_dict, dict) or not data_dict:
        return
    rows = []
    for k, v in data_dict.items():
        if isinstance(v, (dict, list, tuple, set)):
            continue
        rows.append({"metric": k, "value": v})
    if rows:
        uc_excel_sheets[_safe_sheet_name(sheet_name)] = pd.DataFrame(rows)


def _add_uc_dict_rows_sheet(sheet_name, data_dict, key_col_name="name"):
    if not isinstance(data_dict, dict) or not data_dict:
        return
    rows = []
    if all(isinstance(v, dict) for v in data_dict.values()):
        for k, v in data_dict.items():
            row = {key_col_name: k}
            row.update(v)
            rows.append(row)
    else:
        for k, v in data_dict.items():
            if isinstance(v, (dict, list, tuple, set)):
                continue
            rows.append({key_col_name: k, "value": v})
    if rows:
        uc_excel_sheets[_safe_sheet_name(sheet_name)] = pd.DataFrame(rows)


def _add_uc_records_sheet(sheet_name, records):
    if not isinstance(records, list) or len(records) == 0:
        return
    if all(isinstance(x, dict) for x in records):
        df = pd.DataFrame(records)
    else:
        df = pd.DataFrame({"value": records})
    if not df.empty:
        uc_excel_sheets[_safe_sheet_name(sheet_name)] = df


def _extract_uc_tables_from_json(raw):
    """Extract table rows from many possible UC JSON shapes using recursive traversal."""
    if not isinstance(raw, (dict, list)):
        return []

    table_candidates = []

    def _is_table_like(d):
        if not isinstance(d, dict):
            return False
        has_name = any(k in d for k in ['table_name', 'name'])
        has_table_signal = any(k in d for k in [
            'table_type', 'table_format', 'format', 'location',
            'sizeInBytes', 'size_bytes', 'numFiles', 'num_files',
            'partitionColumns', 'partition_columns', 'describe_detail_partition_columns', 'view_definition'
        ])
        has_uc_triplet = all(k in d for k in ['table_catalog', 'table_schema']) and has_name
        return (has_name and has_table_signal) or has_uc_triplet

    def _walk(node, ctx):
        if isinstance(node, list):
            for item in node:
                _walk(item, ctx)
            return

        if not isinstance(node, dict):
            return

        local_ctx = dict(ctx)

        if any(k in node for k in ['schemas', 'databases']) and ('name' in node or 'catalog_name' in node):
            local_ctx['table_catalog'] = node.get('table_catalog') or node.get('catalog_name') or node.get('name')

        if 'tables' in node and ('name' in node or 'schema_name' in node):
            local_ctx['table_schema'] = node.get('table_schema') or node.get('schema_name') or node.get('name')

        if _is_table_like(node):
            rec = dict(node)
            if local_ctx.get('table_catalog') and not (rec.get('table_catalog') or rec.get('catalog_name')):
                rec['table_catalog'] = local_ctx['table_catalog']
            if local_ctx.get('table_schema') and not (rec.get('table_schema') or rec.get('schema_name')):
                rec['table_schema'] = local_ctx['table_schema']
            table_candidates.append(rec)

        for k, v in node.items():
            child_ctx = local_ctx
            if isinstance(v, dict):
                _walk(v, child_ctx)
            elif isinstance(v, list):
                if k in ['catalogs']:
                    for item in v:
                        _ctx = dict(child_ctx)
                        if isinstance(item, dict):
                            _ctx['table_catalog'] = item.get('table_catalog') or item.get('catalog_name') or item.get('name') or _ctx.get('table_catalog')
                        _walk(item, _ctx)
                elif k in ['schemas', 'databases']:
                    for item in v:
                        _ctx = dict(child_ctx)
                        if isinstance(item, dict):
                            _ctx['table_schema'] = item.get('table_schema') or item.get('schema_name') or item.get('name') or _ctx.get('table_schema')
                        _walk(item, _ctx)
                else:
                    for item in v:
                        _walk(item, child_ctx)

    _walk(raw, {'table_catalog': None, 'table_schema': None})

    dedup = []
    seen = set()
    for t in table_candidates:
        table_name = t.get('table_name') or t.get('name') or t.get('table')
        cat = t.get('table_catalog') or t.get('catalog_name') or t.get('catalog') or ''
        sch = t.get('table_schema') or t.get('schema_name') or t.get('schema') or ''
        key = (str(cat), str(sch), str(table_name))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(t)

    return dedup


def _derive_partitioning_strategy(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure partitioning_strategy prefers real partition column names whenever available."""
    if df is None or df.empty:
        return df

    out = df.copy()

    def _parse_partition_cols(value):
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return []

        if isinstance(value, list):
            return [str(i).strip() for i in value if str(i).strip()]

        if isinstance(value, (tuple, set)):
            return [str(i).strip() for i in list(value) if str(i).strip()]

        if isinstance(value, dict):
            for k in ['partition_columns', 'partitionColumns', 'columns', 'keys']:
                if k in value:
                    return _parse_partition_cols(value.get(k))
            return []

        s = str(value).strip()
        if s in ['', '[]', 'None', 'nan', 'null']:
            return []

        # Handle already formatted strategy
        if s.startswith('PARTITION_BY(') and s.endswith(')'):
            inside = s[len('PARTITION_BY('):-1]
            return [i.strip() for i in inside.split(',') if i.strip()]

        # Try JSON parse
        try:
            parsed = json.loads(s)
            return _parse_partition_cols(parsed)
        except Exception:
            pass

        # Generic bracket/comma parse
        return [i.strip().strip("'").strip('"') for i in s.strip('[]').split(',') if i.strip()]

    def _row_partition_cols(row):
        # Search all known direct columns first
        for col in [
            'partition_columns', 'describe_detail_partition_columns',
            'partitionColumns', 'partition_cols', 'partition_keys', 'partitioned_columns'
        ]:
            if col in row:
                value = row[col]
                is_missing = value is None or (isinstance(value, float) and pd.isna(value))
                if not is_missing:
                    cols = _parse_partition_cols(value)
                    if cols:
                        return cols

        # Search nested detail dicts if present
        for nested in ['describe_detail', 'describeDetail', 'details', 'table_details']:
            if nested in row and isinstance(row[nested], dict):
                for key in ['partition_columns', 'partitionColumns', 'partition_cols', 'columns', 'keys']:
                    if key in row[nested]:
                        cols = _parse_partition_cols(row[nested].get(key))
                        if cols:
                            return cols

        return []

    extracted_cols = out.apply(_row_partition_cols, axis=1)

    # Keep normalized partition_columns for downstream uses
    out['partition_columns'] = extracted_cols.apply(lambda cols: cols if cols else None)

    # Derive/normalize partition_count
    if 'partition_count' not in out.columns:
        out['partition_count'] = extracted_cols.apply(len)
    else:
        existing_pc = pd.to_numeric(out['partition_count'], errors='coerce').fillna(0).astype(int)
        derived_pc = extracted_cols.apply(len)
        out['partition_count'] = existing_pc.where(existing_pc > 0, derived_pc)

    # Derive is_partitioned if absent
    if 'is_partitioned' not in out.columns:
        out['is_partitioned'] = pd.to_numeric(out['partition_count'], errors='coerce').fillna(0).astype(int) > 0

    # Build final strategy
    def _strategy_from_row(row):
        cols = row.get('partition_columns') or []
        if isinstance(cols, list) and len(cols) > 0:
            return 'PARTITION_BY(' + ','.join(cols) + ')'

        pc = int(pd.to_numeric(row.get('partition_count', 0), errors='coerce') or 0)
        if pc > 0:
            return f'PARTITIONED(count={pc})'

        if bool(row.get('is_partitioned', False)):
            return 'PARTITIONED'

        return 'NOT_PARTITIONED'

    out['partitioning_strategy'] = out.apply(_strategy_from_row, axis=1)

    return out


# Job Execution Analysis
if data_paths.get('job_execution_input') and os.path.exists(data_paths['job_execution_input']):
    try:
        print("\n--- Job Execution Analysis ---")
        job_exec_analyzer = JobExecutionAnalyzer(
            input_dir=data_paths['job_execution_input'],
            output_dir=temp_dir,
        )
        job_exec_results = job_exec_analyzer.analyze()
        enhanced_results['job_execution'] = job_exec_results

        _add_metric_value_sheet('Job_Summary', job_exec_results.get('summary', {}))

        top_failures_df = job_exec_results.get('top_failures')
        if isinstance(top_failures_df, pd.DataFrame) and not top_failures_df.empty:
            excel_sheets[_safe_sheet_name('Job_Top_Failures')] = top_failures_df

        task_insights = job_exec_results.get('task_insights', {})
        _add_metric_value_sheet('Task_Insights', task_insights)
        _add_records_sheet('Task_Longest', task_insights.get('longest_tasks', []))

        task_failure_rates = task_insights.get('task_failure_rates', {})
        _add_dict_rows_sheet('Task_Failure_Rates', task_failure_rates, key_col_name='task_key')

        print("\n+ Job Execution Analysis complete")
    except Exception as e:
        print(f"Warning: Job Execution analysis failed: {e}")
        import traceback
        traceback.print_exc()
else:
    print("Warning: Job execution data not found (utilization/jobs) - skipping")


# Unity Catalog Governance Analysis - NOW GENERATES SEPARATE EXCEL FILE
if data_paths.get('uc_governance_input') and os.path.exists(data_paths['uc_governance_input']):
    try:
        print("\n--- Unity Catalog Governance Analysis ---")
        uc_analyzer = UnityCatalogGovernanceAnalyzer(
            input_dir=data_paths['uc_governance_input'],
            output_dir=temp_dir,
        )
        uc_results = uc_analyzer.analyze()
        enhanced_results['uc_governance'] = uc_results

        _add_uc_metric_sheet('UC_Catalog_Summary', uc_results.get('catalog_summary', {}))
        _add_uc_metric_sheet('UC_Stale_Insights', uc_results.get('stale_table_insights', {}))
        _add_uc_metric_sheet('UC_Empty_Schemas', uc_results.get('empty_schema_insights', {}))

        stale_insights = uc_results.get('stale_table_insights', {})
        _add_uc_dict_rows_sheet('UC_Stale_By_Category', stale_insights.get('by_category', {}), key_col_name='staleness_category')
        _add_uc_records_sheet('UC_Stale_Tables_Detail', stale_insights.get('top_stale_tables', []))

        empty_insights = uc_results.get('empty_schema_insights', {})
        _add_uc_records_sheet('UC_Empty_Schemas_Detail', empty_insights.get('empty_schemas_list', []))

        print("\n  Loading UC tables with size/partition details...")
        import glob
        import json

        uc_tables_detail = pd.DataFrame()

        search_roots = [
            DISCOVERY_OUTPUT,
            data_paths.get('uc_governance_input'),
            os.path.dirname(data_paths.get('uc_governance_input', '')),
            output_path,
        ]

        csv_patterns = [
            '**/*unity_catalog_tables*.csv',
            '**/*_unity_catalog_tables.csv',
            '**/*_unity_catalog_inventory.csv',
        ]

        csv_candidates = []
        for root in search_roots:
            if isinstance(root, str) and root and os.path.exists(root):
                for pattern in csv_patterns:
                    csv_candidates.extend(glob.glob(os.path.join(root, pattern), recursive=True))

        csv_candidates = list(dict.fromkeys(csv_candidates))

        if csv_candidates:
            csv_candidates = sorted(
                csv_candidates,
                key=lambda p: (0 if 'tables' in os.path.basename(p).lower() else 1, -os.path.getmtime(p))
            )
            chosen_csv = csv_candidates[0]
            print(f"  ✓ Using UC CSV: {chosen_csv}")
            try:
                uc_tables_df = pd.read_csv(chosen_csv)

                rename_map = {
                    'catalog_name': 'table_catalog',
                    'schema_name': 'table_schema',
                    'name': 'table_name',
                    'owner': 'table_owner',
                    'format': 'table_format',
                    'sizeInBytes': 'size_bytes',
                    'size_in_bytes': 'size_bytes',
                    'numFiles': 'num_files',
                    'partitionColumns': 'partition_columns',
                    'partition_cols': 'partition_columns',
                    'describe_detail_partition_columns': 'partition_columns',
                }
                uc_tables_df.rename(columns={k: v for k, v in rename_map.items() if k in uc_tables_df.columns}, inplace=True)

                if 'size_bytes' in uc_tables_df.columns:
                    size_series = pd.to_numeric(uc_tables_df['size_bytes'], errors='coerce').fillna(0)
                    if 'size_mb' not in uc_tables_df.columns:
                        uc_tables_df['size_mb'] = size_series / (1024 * 1024)
                    if 'size_gb' not in uc_tables_df.columns:
                        uc_tables_df['size_gb'] = size_series / (1024 * 1024 * 1024)

                uc_tables_df = _derive_partitioning_strategy(uc_tables_df)
                _strat_counts = uc_tables_df['partitioning_strategy'].value_counts(dropna=False).head(5).to_dict() if 'partitioning_strategy' in uc_tables_df.columns else {}
                print(f"  Partition strategy samples (CSV): {_strat_counts}")

                detail_columns = [
                    'table_catalog', 'table_schema', 'table_name', 'table_type',
                    'size_gb', 'size_mb', 'size_bytes', 'num_files',
                    'is_partitioned', 'partition_count', 'partitioning_strategy',
                    'table_format', 'table_owner',
                    'created_at', 'last_altered'
                ]
                available_cols = [col for col in detail_columns if col in uc_tables_df.columns]

                if 'table_name' in uc_tables_df.columns:
                    uc_tables_df = uc_tables_df[uc_tables_df['table_name'].notna()].copy()

                if available_cols and not uc_tables_df.empty:
                    uc_tables_detail = uc_tables_df[available_cols].copy()
                    if 'size_gb' in uc_tables_detail.columns:
                        uc_tables_detail['size_gb'] = pd.to_numeric(uc_tables_detail['size_gb'], errors='coerce')
                        uc_tables_detail = uc_tables_detail.sort_values('size_gb', ascending=False, na_position='last')
                    print(f"  ✓ Built table detail from CSV with {len(uc_tables_detail)} rows")
                else:
                    print("  ⚠️  CSV found, but no table-level size/partition columns available")

            except Exception as e:
                print(f"  ⚠️  Failed to parse UC CSV: {e}")

        if uc_tables_detail.empty:
            json_patterns = ['**/*_unity_catalog*.json', '**/*unity_catalog*.json']
            json_candidates = []
            for root in search_roots:
                if isinstance(root, str) and root and os.path.exists(root):
                    for pattern in json_patterns:
                        json_candidates.extend(glob.glob(os.path.join(root, pattern), recursive=True))
            json_candidates = list(dict.fromkeys(json_candidates))

            if json_candidates:
                json_candidates = sorted(json_candidates, key=lambda p: -os.path.getmtime(p))
                chosen_json = json_candidates[0]
                print(f"  ✓ Fallback to UC JSON: {chosen_json}")
                try:
                    with open(chosen_json, 'r', encoding='utf-8') as fh:
                        raw = json.load(fh)

                    tables = _extract_uc_tables_from_json(raw)
                    print(f"  ✓ Extracted {len(tables)} table records from JSON")

                    if tables:
                        uc_tables_df = pd.DataFrame(tables)

                        rename_map = {
                            'catalog_name': 'table_catalog',
                            'schema_name': 'table_schema',
                            'name': 'table_name',
                            'owner': 'table_owner',
                            'format': 'table_format',
                            'sizeInBytes': 'size_bytes',
                            'size_in_bytes': 'size_bytes',
                            'numFiles': 'num_files',
                            'partitionColumns': 'partition_columns',
                            'describe_detail_partition_columns': 'partition_columns',
                        }
                        uc_tables_df.rename(columns={k: v for k, v in rename_map.items() if k in uc_tables_df.columns}, inplace=True)

                        if 'size_bytes' in uc_tables_df.columns:
                            size_series = pd.to_numeric(uc_tables_df['size_bytes'], errors='coerce').fillna(0)
                            if 'size_mb' not in uc_tables_df.columns:
                                uc_tables_df['size_mb'] = size_series / (1024 * 1024)
                            if 'size_gb' not in uc_tables_df.columns:
                                uc_tables_df['size_gb'] = size_series / (1024 * 1024 * 1024)

                        uc_tables_df = _derive_partitioning_strategy(uc_tables_df)
                        _strat_counts = uc_tables_df['partitioning_strategy'].value_counts(dropna=False).head(5).to_dict() if 'partitioning_strategy' in uc_tables_df.columns else {}
                        print(f"  Partition strategy samples (JSON): {_strat_counts}")

                        detail_columns = [
                            'table_catalog', 'table_schema', 'table_name', 'table_type',
                            'size_gb', 'size_mb', 'size_bytes', 'num_files',
                            'is_partitioned', 'partition_count', 'partitioning_strategy',
                            'table_format', 'table_owner',
                            'created_at', 'last_altered'
                        ]
                        available_cols = [col for col in detail_columns if col in uc_tables_df.columns]

                        if available_cols:
                            uc_tables_detail = uc_tables_df[available_cols].copy()
                            if 'size_gb' in uc_tables_detail.columns:
                                uc_tables_detail['size_gb'] = pd.to_numeric(uc_tables_detail['size_gb'], errors='coerce')
                                uc_tables_detail = uc_tables_detail.sort_values('size_gb', ascending=False, na_position='last')
                            print(f"  ✓ Built table detail from JSON with {len(uc_tables_detail)} rows")
                except Exception as e:
                    print(f"  ⚠️  Failed to parse UC JSON fallback: {e}")

        if not uc_tables_detail.empty:
            uc_excel_sheets[_safe_sheet_name('UC_All_Tables_Detail')] = uc_tables_detail
            print(f"  ✓ Added UC_All_Tables_Detail sheet with {len(uc_tables_detail)} rows")
        else:
            print("  ⚠️  Could not build UC_All_Tables_Detail from available discovery artifacts")

        uc_generated = True
        print("\n+ Unity Catalog Governance Analysis complete (will generate separate Excel)")
    except Exception as e:
        print(f"Warning: UC Governance analysis failed: {e}")
        import traceback
        traceback.print_exc()
else:
    print("Warning: Unity Catalog governance data not found (utilization/unity_catalog) - skipping")


# DLT Pipeline Analysis
if data_paths.get('dlt_pipeline_input') and os.path.exists(data_paths['dlt_pipeline_input']):
    try:
        print("\n--- DLT Pipeline Analysis ---")
        dlt_analyzer = DLTPipelineAnalyzer(
            input_dir=data_paths['dlt_pipeline_input'],
            output_dir=temp_dir,
        )
        dlt_results = dlt_analyzer.analyze()
        enhanced_results['dlt_pipelines'] = dlt_results

        _add_metric_value_sheet('DLT_Summary', dlt_results.get('summary', {}))
        _add_metric_value_sheet('DLT_Failure_Analysis', dlt_results.get('failure_analysis', {}))

        dlt_perf = dlt_results.get('performance', {})
        _add_metric_value_sheet('DLT_Performance', dlt_perf)
        _add_records_sheet('DLT_Slowest_Updates', dlt_perf.get('slowest_updates', []))

        print("\n+ DLT Pipeline Analysis complete")
    except Exception as e:
        print(f"Warning: DLT Pipeline analysis failed: {e}")
        import traceback
        traceback.print_exc()
else:
    print("Warning: DLT pipeline data not found (utilization/dlt) - skipping")


# Cost Attribution Analysis
if data_paths.get('cost_attribution_input') and os.path.exists(data_paths['cost_attribution_input']):
    try:
        print("\n--- Cost Attribution Analysis ---")
        cost_analyzer = CostAttributionAnalyzer(
            input_dir=data_paths['cost_attribution_input'],
            output_dir=temp_dir,
        )
        cost_results = cost_analyzer.analyze()
        enhanced_results['cost_attribution'] = cost_results

        cluster_summary = cost_results.get('cluster_cost_summary', {})
        job_summary = cost_results.get('job_cost_summary', {})

        _add_metric_value_sheet('Cost_Cluster_Summary', cluster_summary)
        _add_metric_value_sheet('Cost_Job_Summary', job_summary)
        _add_records_sheet('Cost_Top_Clusters', cluster_summary.get('top_costly_clusters', []))
        _add_records_sheet('Cost_Top_Jobs', job_summary.get('top_costly_jobs', []))

        # Serverless interactive notebook cost (billing_origin_product = 'INTERACTIVE').
        # Captures notebooks run interactively on serverless compute, which carry no
        # cluster_id / job_id / warehouse_id and are therefore absent from the
        # cluster, job, and SQL query usage cost breakdowns.
        serverless_summary = cost_results.get('serverless_notebook_summary', {})
        _add_metric_value_sheet('Cost_Serverless_Notebook_Summary', serverless_summary)
        _add_records_sheet('Cost_Top_Serverless_Notebooks', serverless_summary.get('top_costly_notebooks', []))
        
        # Serverless vs Standard comparison.
        # Prefer the analyzer-provided breakdown. If it is missing (older
        # toolkit build, or the analyzer skipped it because the explicit
        # flag was absent), rebuild it here directly from the loaded
        # cost-by-job data so the sheet still appears whenever the
        # underlying data carries serverless / SKU information.
        serverless_comparison = job_summary.get('serverless_comparison')

        if not serverless_comparison:
            _cbj = getattr(cost_analyzer, 'cost_by_job', None)
            if _cbj is not None and not _cbj.empty:
                _cbj = _cbj.copy()

                # Derive is_serverless from sku_name when the explicit flag is absent
                if 'is_serverless' not in _cbj.columns and 'sku_name' in _cbj.columns:
                    _cbj['is_serverless'] = (
                        _cbj['sku_name'].astype(str).str.upper().str.contains('SERVERLESS')
                    )

                if 'is_serverless' in _cbj.columns:
                    _cbj['is_serverless'] = _cbj['is_serverless'].fillna(False).astype(bool)
                    for _c in ['total_dbus', 'estimated_cost_usd', 'total_runs']:
                        if _c not in _cbj.columns:
                            _cbj[_c] = 0
                        _cbj[_c] = pd.to_numeric(_cbj[_c], errors='coerce').fillna(0)

                    _grp = _cbj.groupby('is_serverless').agg(
                        job_count=('job_id', 'count'),
                        total_dbus=('total_dbus', 'sum'),
                        estimated_cost_usd=('estimated_cost_usd', 'sum'),
                        total_runs=('total_runs', 'sum'),
                    ).reset_index()

                    _tot_cost = float(_grp['estimated_cost_usd'].sum())
                    _tot_dbus = float(_grp['total_dbus'].sum())

                    serverless_comparison = []
                    for _, _r in _grp.iterrows():
                        _jc = int(_r['job_count'])
                        _rd = float(_r['total_dbus'])
                        _rc = float(_r['estimated_cost_usd'])
                        serverless_comparison.append({
                            'compute_type': 'Serverless' if _r['is_serverless'] else 'Standard',
                            'job_count': _jc,
                            'total_dbus': _rd,
                            'total_cost_usd': _rc,
                            'total_runs': int(_r['total_runs']),
                            'avg_dbus_per_job': _rd / _jc if _jc else 0,
                            'avg_cost_per_job': _rc / _jc if _jc else 0,
                            'pct_of_total_cost': (_rc / _tot_cost * 100) if _tot_cost else 0,
                            'pct_of_total_dbus': (_rd / _tot_dbus * 100) if _tot_dbus else 0,
                        })

                    _tot_jobs = int(_grp['job_count'].sum())
                    serverless_comparison.append({
                        'compute_type': 'TOTAL',
                        'job_count': _tot_jobs,
                        'total_dbus': _tot_dbus,
                        'total_cost_usd': _tot_cost,
                        'total_runs': int(_grp['total_runs'].sum()),
                        'avg_dbus_per_job': _tot_dbus / _tot_jobs if _tot_jobs else 0,
                        'avg_cost_per_job': _tot_cost / _tot_jobs if _tot_jobs else 0,
                        'pct_of_total_cost': 100.0 if _tot_cost else 0,
                        'pct_of_total_dbus': 100.0 if _tot_dbus else 0,
                    })
                    print("  + Rebuilt Serverless vs Standard comparison from cost-by-job data")
                else:
                    print("  Warning: Serverless vs Standard skipped - cost-by-job data has no "
                          "'sku_name'/'is_serverless' columns")
                    print("           Re-run discovery (notebook 01) with the updated toolkit "
                          "to collect serverless cost attribution")

        if serverless_comparison:
            _add_records_sheet('Cost_Serverless_vs_Standard', serverless_comparison)
            print("  + Added Serverless vs Standard comparison sheet")

        print("\n+ Cost Attribution Analysis complete")
    except Exception as e:
        print(f"Warning: Cost Attribution analysis failed: {e}")
        import traceback
        traceback.print_exc()
else:
    print("Warning: Cost attribution data not found (utilization/cost) - skipping")


# Write all results to Excel file (Job Execution, DLT, Cost Attribution)
if excel_sheets:
    try:
        print("\n" + "=" * 80)
        print("WRITING ADVANCED ANALYSIS TO EXCEL")
        print("=" * 80)

        workspace_id_raw = ''
        for key in [
            'cluster_input',
            'jobs_input',
            'job_execution_input',
            'uc_governance_input',
            'dlt_pipeline_input',
            'cost_attribution_input',
        ]:
            val = data_paths.get(key)
            if isinstance(val, str) and val:
                m = re.search(r'adb-?(\d+)', val)
                if m:
                    workspace_id_raw = m.group(1)
                    break

        if not workspace_id_raw:
            workspace_id_raw = 'workspace'

        excel_filename = f"advance_analysis_{workspace_id_raw}_{timestamp}.xlsx"
        excel_path = os.path.join(output_path, excel_filename)
        local_excel_path = f"/tmp/{excel_filename}"

        with pd.ExcelWriter(local_excel_path, engine='openpyxl') as writer:
            for sheet_name, df in excel_sheets.items():
                safe_sheet_name = _safe_sheet_name(sheet_name)
                df.to_excel(writer, sheet_name=safe_sheet_name, index=False)
                print(f"  + Written sheet: {safe_sheet_name} ({len(df)} rows)")

        os.makedirs(output_path, exist_ok=True)
        try:
            shutil.copy2(local_excel_path, excel_path)
        except Exception:
            _dbfs_target = excel_path
            if _dbfs_target.startswith('/dbfs/'):
                _dbfs_target = 'dbfs:/' + _dbfs_target[len('/dbfs/'):]
            elif _dbfs_target.startswith('/Volumes/'):
                _dbfs_target = 'dbfs:' + _dbfs_target
            dbutils.fs.cp(f"file:{local_excel_path}", _dbfs_target, True)

        print(f"\n+ Advanced analysis saved to: {excel_filename}")
        print(f"  + Full path: {excel_path}")
        reports_generated.append(f"Advanced Analysis: {excel_filename}")

    except Exception as e:
        print(f"Warning: Failed to write Excel file: {e}")
        import traceback
        traceback.print_exc()
else:
    print("\nWarning: No enhanced analysis data available to write to Excel")


# Write Unity Catalog analysis to separate Excel file
if uc_generated and uc_excel_sheets:
    try:
        print("\n" + "=" * 80)
        print("WRITING UNITY CATALOG ANALYSIS TO SEPARATE EXCEL")
        print("=" * 80)

        workspace_id_raw = ''
        for key in [
            'cluster_input',
            'jobs_input',
            'job_execution_input',
            'uc_governance_input',
            'dlt_pipeline_input',
            'cost_attribution_input',
        ]:
            val = data_paths.get(key)
            if isinstance(val, str) and val:
                m = re.search(r'adb-?(\d+)', val)
                if m:
                    workspace_id_raw = m.group(1)
                    break

        if not workspace_id_raw:
            workspace_id_raw = 'workspace'

        uc_excel_filename = f"uc_analysis_{workspace_id_raw}_{timestamp}.xlsx"
        uc_excel_path = os.path.join(output_path, uc_excel_filename)
        local_uc_excel_path = f"/tmp/{uc_excel_filename}"

        with pd.ExcelWriter(local_uc_excel_path, engine='openpyxl') as writer:
            for sheet_name, df in uc_excel_sheets.items():
                safe_sheet_name = _safe_sheet_name(sheet_name)
                df.to_excel(writer, sheet_name=safe_sheet_name, index=False)
                print(f"  + Written sheet: {safe_sheet_name} ({len(df)} rows)")

        os.makedirs(output_path, exist_ok=True)
        try:
            shutil.copy2(local_uc_excel_path, uc_excel_path)
        except Exception:
            _dbfs_target = uc_excel_path
            if _dbfs_target.startswith('/dbfs/'):
                _dbfs_target = 'dbfs:/' + _dbfs_target[len('/dbfs/'):]
            elif _dbfs_target.startswith('/Volumes/'):
                _dbfs_target = 'dbfs:' + _dbfs_target
            dbutils.fs.cp(f"file:{local_uc_excel_path}", _dbfs_target, True)

        print(f"\n+ Unity Catalog analysis saved to: {uc_excel_filename}")
        print(f"  + Full path: {uc_excel_path}")
        reports_generated.append(f"Unity Catalog Analysis: {uc_excel_filename}")

    except Exception as e:
        print(f"Warning: Failed to write UC Excel file: {e}")
        import traceback
        traceback.print_exc()
elif uc_generated and not uc_excel_sheets:
    print("\nWarning: UC analysis ran but generated no sheets")
elif not uc_generated:
    print("\nInfo: Unity Catalog analysis was skipped (no UC data)")


print("\n" + "=" * 80)
print("+ ENHANCED UTILIZATION ANALYSIS COMPLETE")
print("=" * 80)

# COMMAND ----------

# print("="*80)
# print("RUNNING COMPREHENSIVE WORKSPACE ANALYSIS")
# print("="*80)
# print(f"\nThis will generate:")
# print(f"  1. Cluster Analysis (7 analyzers consolidated)")
# print(f"  2. Job Analysis")
# print(f"  3. Query Analysis (if data available)")
# print(f"  4. Security Analysis (if data available)")
# print(f"  5. Spark Job Optimizer Analysis (if data available)")
# print(f"\nOutput: {ANALYSIS_OUTPUT}")
# print("="*80 + "\n")

# # Create temporary directory with proper cleanup
# temp_dir = os.path.join(ANALYSIS_TEMP_DIR, 'comprehensive')

# # Clean up any existing temp directory first
# if os.path.exists(ANALYSIS_TEMP_DIR):
#     try:
#         shutil.rmtree(ANALYSIS_TEMP_DIR)
#         print(f"✓ Cleaned up existing temp directory")
#     except Exception as e:
#         print(f"⚠️  Warning: Could not clean existing temp dir: {e}")

# # Create fresh temp directory
# try:
#     os.makedirs(temp_dir, mode=0o777, exist_ok=True)
#     print(f"✓ Created temp directory: {temp_dir}")
# except Exception as e:
#     print(f"❌ Error creating temp directory: {e}")
#     # Fallback to a simpler path
#     temp_dir = f"/tmp/analysis_{timestamp}"
#     os.makedirs(temp_dir, mode=0o777, exist_ok=True)
#     print(f"✓ Using fallback temp directory: {temp_dir}")

# # Determine output path based on storage type
# if ANALYSIS_OUTPUT.startswith('/Volumes/'):
#     output_path = ANALYSIS_OUTPUT
# elif ANALYSIS_OUTPUT.startswith('/dbfs/') or ANALYSIS_OUTPUT.startswith('dbfs:/'):
#     output_path = ANALYSIS_OUTPUT.replace('dbfs:/', '/dbfs/')
#     if not output_path.startswith('/dbfs'):
#         output_path = '/dbfs' + output_path
# else:
#     output_path = '/dbfs' + ANALYSIS_OUTPUT

# os.makedirs(output_path, exist_ok=True)

# reports_generated = []
# sjo_scan_result   = None   # declared here so the preview and Delta cells can reference it
# sjo_analyzer      = SparkJobOptimizerAnalyzer({})

# try:
#     # =========================================================================
#     # 1. CLUSTER + JOB ANALYSIS
#     # =========================================================================
#     print(f"\n{'='*80}")
#     print("STEP 1/5: RUNNING CLUSTER + JOB ANALYSIS")
#     print(f"{'='*80}\n")
    
#     cluster_results = run_consolidated_cluster_analysis(
#         cluster_input_path=data_paths['cluster_input'],
#         output_dir=temp_dir,
#         job_input_path=data_paths['jobs_input'],
#         rules_path=RULES_PATH
#     )
    
#     # Copy cluster report
#     if cluster_results.get('cluster_output_file') and os.path.exists(cluster_results['cluster_output_file']):
#         cluster_dst = os.path.join(output_path, os.path.basename(cluster_results['cluster_output_file']))
#         shutil.copy2(cluster_results['cluster_output_file'], cluster_dst)
#         reports_generated.append(f"Cluster Analysis: {os.path.basename(cluster_results['cluster_output_file'])}")
#         print(f"\n✓ Cluster report saved: {os.path.basename(cluster_results['cluster_output_file'])}")
    
#     # Copy job report
#     if cluster_results.get('job_output_file') and os.path.exists(cluster_results['job_output_file']):
#         job_dst = os.path.join(output_path, os.path.basename(cluster_results['job_output_file']))
#         shutil.copy2(cluster_results['job_output_file'], job_dst)
#         reports_generated.append(f"Job Analysis: {os.path.basename(cluster_results['job_output_file'])}")
#         print(f"✓ Job report saved: {os.path.basename(cluster_results['job_output_file'])}")
    
#     # =========================================================================
#     # 2. QUERY ANALYSIS
#     # =========================================================================
#     print(f"\n{'='*80}")
#     print("STEP 2/5: RUNNING QUERY ANALYSIS")
#     print(f"{'='*80}\n")
    
#     if data_paths['query_input'] and os.path.exists(data_paths['query_input']):
#         try:
#             query_analyzer = QueryUtilizationAnalyzer(
#                 input_path=data_paths['query_input'],
#                 output_dir=temp_dir
#             )
            
#             query_results = query_analyzer.analyze()
            
#             # Copy query report
#             if query_results.get('output_file') and os.path.exists(query_results['output_file']):
#                 query_dst = os.path.join(output_path, os.path.basename(query_results['output_file']))
#                 shutil.copy2(query_results['output_file'], query_dst)
#                 reports_generated.append(f"Query Analysis: {os.path.basename(query_results['output_file'])}")
#                 print(f"\n✓ Query report saved: {os.path.basename(query_results['output_file'])}")
#         except FileNotFoundError as e:
#             print(f"⚠️  Query data not found: {e}")
#             print("   This is normal if no SQL Warehouses were active during discovery")
#         except Exception as e:
#             print(f"⚠️  Query analysis skipped: {e}")
#     else:
#         print("⚠️  Query data not found - skipping query analysis")
#         print("   This is normal if no SQL Warehouses were active during discovery")
    
#     # =========================================================================
#     # 3. SECURITY ANALYSIS
#     # =========================================================================
#     print(f"\n{'='*80}")
#     print("STEP 3/5: RUNNING SECURITY ANALYSIS")
#     print(f"{'='*80}\n")
    
#     if data_paths['security_input'] and os.path.exists(data_paths['security_input']):
#         try:
#             print(f"✓ Security data located: {data_paths['security_input']}")
            
#             security_analyzer = SecurityAnalyzer(
#                 discovery_path=data_paths['security_input'],
#                 output_dir=temp_dir
#             )
            
#             security_results = security_analyzer.analyze()
            
#             # Copy security report - handle different return structures
#             output_file = None
            
#             # Debug: print what we got back
#             print(f"\nDebug - security_results keys: {security_results.keys()}")
            
#             # Try different keys and structures
#             if 'output_files' in security_results:
#                 result_data = security_results['output_files']
#                 if isinstance(result_data, dict):
#                     output_file = result_data.get('xlsx') or result_data.get('excel') or result_data.get('file')
#                 elif isinstance(result_data, str):
#                     output_file = result_data
#             elif 'output_file' in security_results:
#                 output_file = security_results['output_file']
            
#             # If still no file, try to find any xlsx file in temp_dir
#             if not output_file:
#                 print("Debug - Searching temp directory for security report...")
#                 for file in os.listdir(temp_dir):
#                     if file.startswith('Security_Analysis') and file.endswith('.xlsx'):
#                         output_file = os.path.join(temp_dir, file)
#                         print(f"Debug - Found security report: {output_file}")
#                         break
            
#             if output_file and isinstance(output_file, str) and os.path.exists(output_file):
#                 security_dst = os.path.join(output_path, os.path.basename(output_file))
#                 shutil.copy2(output_file, security_dst)
#                 reports_generated.append(f"Security Analysis: {os.path.basename(output_file)}")
#                 print(f"\n✓ Security report saved: {os.path.basename(output_file)}")
#             else:
#                 print(f"⚠️  Security report file not found")
#                 print(f"   Result structure: {security_results}")
#         except Exception as e:
#             print(f"⚠️  Security analysis failed: {e}")
#             import traceback
#             traceback.print_exc()
#     else:
#         print("⚠️  Security data not found - skipping security analysis")
#         print("   Run discovery with scan_type='deep' to collect security data")

#     # =========================================================================
#     # 4. SPARK JOB OPTIMIZER ANALYSIS
#     # =========================================================================
#     print(f"\n{'='*80}")
#     print("STEP 4/5: RUNNING SPARK JOB OPTIMIZER ANALYSIS")
#     print(f"{'='*80}\n")

#     if data_paths.get('spark_optimizer_input') and os.path.exists(data_paths['spark_optimizer_input']):
#         try:
#             import json as _json
#             import pandas as pd
#             from datetime import datetime as _dt

#             _sjo_file = data_paths['spark_optimizer_input']
#             _sjo_ext  = os.path.splitext(_sjo_file)[1].lower()
#             print(f"✓ Spark optimizer data: {_sjo_file}")

#             def _to_df(records):
#                 return pd.DataFrame(records) if records else pd.DataFrame()

#             if _sjo_ext == '.json':
#                 with open(_sjo_file, encoding='utf-8') as _fh:
#                     _raw = _json.load(_fh)
#                 # scanner output: {'metadata': ..., 'spark_job_optimizer': {...}}
#                 _sjo_data = _raw.get('spark_job_optimizer', _raw)
#                 _summary  = _sjo_data.get('summary', {})

#             elif _sjo_ext == '.csv':
#                 _csv_df   = pd.read_csv(_sjo_file)
#                 _ws_id    = str(_csv_df['workspace_id'].iloc[0])   if 'workspace_id'   in _csv_df.columns and len(_csv_df) else ''
#                 _ws_name  = str(_csv_df['workspace_name'].iloc[0]) if 'workspace_name' in _csv_df.columns and len(_csv_df) else ''
#                 _ts_str   = str(_csv_df['scan_timestamp'].iloc[0]) if 'scan_timestamp' in _csv_df.columns and len(_csv_df) else ''
#                 _lb       = int(_csv_df['lookback_days'].iloc[0])  if 'lookback_days'  in _csv_df.columns and len(_csv_df) else 30
#                 _base_cols = {'workspace_id', 'workspace_name', 'scan_timestamp', 'lookback_days', 'category'}
#                 # flatten_for_csv uses category column to tag each row
#                 _cat_key_map = {
#                     'data_skew':            'skewed_jobs',
#                     'shuffle_spill':        'shuffle_spill_jobs',
#                     'broadcast_candidates': 'broadcast_candidates',
#                     'long_running_jobs':    'long_running_jobs',
#                     'failed_tasks':         'failed_tasks',
#                 }
#                 _sjo_data = {'summary': {
#                     'workspace_id': _ws_id, 'workspace_name': _ws_name,
#                     'scan_timestamp': _ts_str, 'lookback_days': _lb,
#                 }}
#                 for _cat, _key in _cat_key_map.items():
#                     _sub = _csv_df[_csv_df['category'] == _cat] if 'category' in _csv_df.columns else pd.DataFrame()
#                     _sjo_data[_key] = _sub.drop(
#                         columns=[c for c in _base_cols if c in _sub.columns], errors='ignore'
#                     ).to_dict(orient='records')
#                 _summary = _sjo_data['summary']
#             else:
#                 raise ValueError(f"Unsupported spark optimizer file format: {_sjo_ext}")

#             # Reconstruct ScanResult from saved dict
#             try:
#                 _scan_ts = _dt.fromisoformat(str(_summary.get('scan_timestamp', '')))
#             except Exception:
#                 _scan_ts = _dt.now()

#             sjo_scan_result = SparkScanResult(
#                 workspace_id         = _summary.get('workspace_id',   ''),
#                 workspace_name       = _summary.get('workspace_name', ''),
#                 scan_timestamp       = _scan_ts,
#                 scan_mode            = _summary.get('scan_mode',      'deep'),
#                 lookback_days        = int(_summary.get('lookback_days', 30)),
#                 skewed_jobs          = _to_df(_sjo_data.get('skewed_jobs',          [])),
#                 shuffle_spill_jobs   = _to_df(_sjo_data.get('shuffle_spill_jobs',   [])),
#                 broadcast_candidates = _to_df(_sjo_data.get('broadcast_candidates', [])),
#                 long_running_jobs    = _to_df(_sjo_data.get('long_running_jobs',    [])),
#                 failed_tasks         = _to_df(_sjo_data.get('failed_tasks',         [])),
#             )
#             print(f"  Total findings loaded: {sjo_scan_result.total_findings}")

#             # Generate Excel report
#             _ws_slug      = (sjo_scan_result.workspace_id or 'workspace').replace('/', '_')
#             _sjo_rpt_name = f"Spark_Job_Optimizer_{_ws_slug}.xlsx"
#             _sjo_rpt_tmp  = os.path.join(temp_dir, _sjo_rpt_name)

#             sjo_analyzer.generate_report(sjo_scan_result, _sjo_rpt_tmp)

#             if os.path.exists(_sjo_rpt_tmp):
#                 shutil.copy2(_sjo_rpt_tmp, os.path.join(output_path, _sjo_rpt_name))
#                 reports_generated.append(f"Spark Job Optimizer: {_sjo_rpt_name}")
#                 print(f"✓ Spark Job Optimizer report saved: {_sjo_rpt_name}")

#         except Exception as e:
#             print(f"⚠️  Spark Job Optimizer analysis failed: {e}")
#             import traceback
#             traceback.print_exc()
#     else:
#         print("⚠️  Spark optimizer data not found — skipping")
#         print("   Enable spark_job_optimizer in config.json and re-run discovery")

#     # =========================================================================
#     # SUMMARY
#     # =========================================================================
#     print(f"\n{'='*80}")
#     print("✓ COMPREHENSIVE ANALYSIS COMPLETE")
#     print(f"{'='*80}\n")
    
#     print(f"Generated {len(reports_generated)} report(s):\n")
#     for report in reports_generated:
#         print(f"  📊 {report}")
    
#     print(f"\nAll reports saved to: {ANALYSIS_OUTPUT}")
#     print(f"\n{'='*80}")
    
# except Exception as e:
#     print(f"\n❌ Error during comprehensive analysis: {str(e)}")
#     import traceback
#     traceback.print_exc()
    
# finally:
#     # Clean up temporary files
#     try:
#         if os.path.exists(ANALYSIS_TEMP_DIR):
#             shutil.rmtree(ANALYSIS_TEMP_DIR)
#             print(f"\n✓ Cleaned up temporary files")
#         elif os.path.exists(temp_dir):
#             shutil.rmtree(temp_dir)
#             print(f"\n✓ Cleaned up temporary files")
#     except Exception as e:
#         print(f"⚠️  Warning: Could not clean up temp files: {e}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## View Generated Reports
# MAGIC
# MAGIC List all Excel reports generated by the analysis.

# COMMAND ----------

print("="*80)
print("ANALYSIS REPORTS GENERATED")
print("="*80)
print(f"\nOutput directory: {ANALYSIS_OUTPUT}\n")

try:
    files = dbutils.fs.ls(ANALYSIS_OUTPUT)
    
    excel_files = [f for f in files if f.name.endswith('.xlsx')]
    
    if excel_files:
        print(f"Found {len(excel_files)} Excel report(s):\n")
        for file_info in sorted(excel_files, key=lambda x: x.name):
            size_mb = file_info.size / (1024*1024)
            print(f"  📊 {file_info.name}")
            print(f"     Size: {size_mb:.2f} MB")
            print(f"     Path: {file_info.path}\n")
    else:
        print("⚠️  No Excel reports found")
        
except Exception as e:
    print(f"Error listing reports: {e}")

print("="*80)
print("✓ ANALYSIS COMPLETE")
print("="*80)
print("\n📥 Download the Excel reports to view detailed analysis and recommendations.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preview Analysis Results Before Saving to Delta Tables
# MAGIC
# MAGIC Review the summaries below. Once satisfied, run the **Confirm Insert** cell and set the widget to **Yes**, then run the **Insert into Delta Tables** cell to persist the data to Unity Catalog.

# COMMAND ----------

import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# Helper: safe display for DataFrames in Databricks
# Coerces all object-dtype columns to str to prevent Arrow serialisation
# failures caused by mixed-type columns (int / str / None in the same column).
# ─────────────────────────────────────────────────────────────────────────────
def _safe_df(df):
    """Return a copy of df with every object-dtype column cast to str."""
    df = df.copy()
    for col in df.select_dtypes(include='object').columns:
        df[col] = df[col].astype(str)
    return df


def _show(df, title, max_rows=50):
    print(f"\n{'='*80}")
    print(f"  {title}")
    print(f"{'='*80}")
    if df is None or (hasattr(df, '__len__') and len(df) == 0):
        print("  (no data)")
        return
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 200)
    pd.set_option('display.max_colwidth', 60)
    _df = _safe_df(df.head(max_rows))
    try:
        display(_df)          # Databricks rich display
    except NameError:
        print(_df.to_string(index=False))


# ─────────────────────────────────────────────────────────────────────────────
# 1. CLUSTER ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    cluster_df_raw = cluster_results.get('analysis_results', {}).get('utilization', {}).get('cluster_data')
    if cluster_df_raw is not None and not cluster_df_raw.empty:
        preview_cols = [c for c in [
            'cluster_name', 'driver_node_type', 'worker_node_type',
            'Avg CPU Utilization', 'Peak CPU Utilization',
            'Avg Memory Utilization', 'Avg CPU Wait',
            'Avg Network MB Received', 'Avg Network MB Sent',
            'Category', 'Recommendation'
        ] if c in cluster_df_raw.columns]

        cluster_preview = cluster_df_raw[preview_cols].copy()
        cluster_preview.index.name = 'cluster_id'

        # Category breakdown
        print("\n" + "="*80)
        print("  CLUSTER ANALYSIS — Category Breakdown")
        print("="*80)
        cat_summary = cluster_df_raw['Category'].value_counts().reset_index()
        cat_summary.columns = ['Category', 'Count']
        try:
            display(_safe_df(cat_summary))
        except NameError:
            print(cat_summary.to_string(index=False))

        _show(cluster_preview.reset_index(), "CLUSTER ANALYSIS — Per-Cluster Metrics (first 50 rows)")
    else:
        print("⚠️  Cluster analysis data not available in this session")
except Exception as e:
    print(f"⚠️  Could not display cluster data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. JOB ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    job_stats = cluster_results.get('job_stats') or {}
    print("\n" + "="*80)
    print("  JOB ANALYSIS — Summary Statistics")
    print("="*80)
    job_summary_rows = [
        {'Metric': 'Total Jobs',   'Value': str(job_stats.get('total_jobs', 'N/A'))},
        {'Metric': 'Workspace ID', 'Value': str(job_stats.get('workspace_id', 'N/A'))},
        {'Metric': 'Scan Time',    'Value': str(job_stats.get('scan_time', 'N/A'))},
    ]
    job_summary_df = pd.DataFrame(job_summary_rows)
    try:
        display(job_summary_df)
    except NameError:
        print(job_summary_df.to_string(index=False))

    # Attempt to load detailed per-job data for preview
    if data_paths.get('jobs_input') and os.path.exists(data_paths['jobs_input']):
        try:
            from databricks_toolkit.analysis.job_analyzer import JobAnalyzer
            _preview_job_analyzer = JobAnalyzer(data_paths['jobs_input'], '/tmp')
            _preview_job_analyzer.load_data()
            _job_detail_list = []
            for _j in _preview_job_analyzer.jobs_data[:100]:
                _tasks = _j.get('tasks', [])
                _runs  = _j.get('recent_runs', [])
                _job_detail_list.append({
                    'Job ID':            str(_j.get('job_id', '')),
                    'Job Name':          str(_j.get('job_name', 'Unknown')),
                    'Creator':           str(_j.get('creator_user_name', 'Unknown')),
                    'Format':            str(_j.get('format', 'SINGLE_TASK')),
                    'Task Count':        int(len(_tasks)),
                    'Has Notifications': bool(_j.get('email_notifications', {}).get('on_failure')),
                    'Has Retry':         bool(any(t.get('max_retries', 0) for t in _tasks)),
                    'Recent Runs':       int(len(_runs)),
                    'Has Failed Run':    bool(any(r.get('result_state', '').upper() == 'FAILED' for r in _runs)),
                })
            _show(pd.DataFrame(_job_detail_list), "JOB ANALYSIS — Per-Job Preview (first 100 jobs)")
        except Exception as je:
            print(f"  (Detailed per-job preview skipped: {je})")
except Exception as e:
    print(f"⚠️  Could not display job data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 3. SECURITY ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if 'security_results' in dir() or 'security_results' in globals():
        sec_score  = security_results.get('security_score', 'N/A')
        sec_grade  = security_results.get('grade', 'N/A')
        sec_total  = security_results.get('total_findings', 0)
        sec_high   = security_results.get('high_severity_count', 0)
        sec_medium = security_results.get('medium_severity_count', 0)
        sec_low    = security_results.get('low_severity_count', 0)

        print("\n" + "="*80)
        print("  SECURITY ANALYSIS — Score Card")
        print("="*80)
        sec_card = pd.DataFrame([
            {'Metric': 'Security Score',  'Value': f"{sec_score}/100"},
            {'Metric': 'Grade',           'Value': str(sec_grade)},
            {'Metric': 'Total Findings',  'Value': str(sec_total)},
            {'Metric': 'High Severity',   'Value': str(sec_high)},
            {'Metric': 'Medium Severity', 'Value': str(sec_medium)},
            {'Metric': 'Low Severity',    'Value': str(sec_low)},
        ])
        try:
            display(sec_card)
        except NameError:
            print(sec_card.to_string(index=False))

        findings_list = security_results.get('findings', [])
        if findings_list:
            findings_cols = ['check_id', 'check_name', 'category_name', 'severity', 'status',
                             'current_value', 'recommendation']
            findings_df = pd.DataFrame(findings_list)
            findings_df = findings_df[[c for c in findings_cols if c in findings_df.columns]]
            _show(findings_df, "SECURITY ANALYSIS — All Findings")
    else:
        print("⚠️  Security analysis data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display security data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 4. QUERY ANALYSIS PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if 'query_results' in dir() or 'query_results' in globals():
        print("\n" + "="*80)
        print("  QUERY ANALYSIS — Summary Statistics")
        print("="*80)
        q_summary = pd.DataFrame([
            {'Metric': 'Total Queries',     'Value': str(query_results.get('total_queries', 'N/A'))},
            {'Metric': 'Unique Users',      'Value': str(query_results.get('unique_users', 'N/A'))},
            {'Metric': 'Unique Warehouses', 'Value': str(query_results.get('unique_warehouses', 'N/A'))},
            {'Metric': 'Failed Queries',    'Value': str(query_results.get('failed_queries', 'N/A'))},
            {'Metric': 'Avg Duration (sec)','Value': str(round(query_results.get('avg_duration_seconds', 0), 2))},
        ])
        try:
            display(q_summary)
        except NameError:
            print(q_summary.to_string(index=False))

        user_stats_df = query_results.get('user_stats')
        if user_stats_df is not None and not user_stats_df.empty:
            _show(user_stats_df.head(20), "QUERY ANALYSIS — Top Users by Cost")

        wh_stats_df = query_results.get('warehouse_stats')
        if wh_stats_df is not None and not wh_stats_df.empty:
            _show(wh_stats_df.head(20), "QUERY ANALYSIS — Per-Warehouse Summary")

        if 'query_analyzer' in dir() or 'query_analyzer' in globals():
            raw_q = getattr(query_analyzer, 'query_data', None)
            if raw_q is not None and not raw_q.empty:
                q_cols = [c for c in ['query_id', 'warehouse_id', 'executed_by',
                                       'duration_seconds', 'is_failed', 'estimated_dbu_cost']
                          if c in raw_q.columns]
                _show(raw_q[q_cols].head(50), "QUERY ANALYSIS — Raw Query Data (first 50)")
    else:
        print("⚠️  Query analysis data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display query data: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 5. SPARK JOB OPTIMIZER PREVIEW
# ─────────────────────────────────────────────────────────────────────────────
try:
    if sjo_scan_result is not None and sjo_scan_result.total_findings > 0:
        print("\n" + "="*80)
        print("  SPARK JOB OPTIMIZER — Summary")
        print("="*80)

        _attr_label = [
            ('skewed_jobs',          'Data Skew'),
            ('shuffle_spill_jobs',   'Shuffle Spill'),
            ('broadcast_candidates', 'Broadcast Candidates'),
            ('long_running_jobs',    'Long-Running Jobs'),
            ('failed_tasks',         'Failed Tasks'),
        ]
        sjo_summary_rows = []
        for _attr, _label in _attr_label:
            _df = getattr(sjo_scan_result, _attr, pd.DataFrame())
            sjo_summary_rows.append({'Category': _label, 'Findings': 0 if _df is None or _df.empty else len(_df)})
        sjo_summary_rows.append({'Category': 'TOTAL', 'Findings': sjo_scan_result.total_findings})

        _sjo_summary_df = pd.DataFrame(sjo_summary_rows)
        try:
            display(_safe_df(_sjo_summary_df))
        except NameError:
            print(_sjo_summary_df.to_string(index=False))

        # Top findings per category
        for _attr, _label in _attr_label:
            _df = getattr(sjo_scan_result, _attr, pd.DataFrame())
            if _df is not None and not _df.empty:
                _show(_df.head(10), f"SPARK JOB OPTIMIZER — {_label} (first 10)")
    else:
        print("⚠️  Spark Job Optimizer data not available (was it skipped?)")
except Exception as e:
    print(f"⚠️  Could not display Spark Job Optimizer data: {e}")


print("\n" + "="*80)
print("  PREVIEW COMPLETE — proceed to the next cell to configure Delta insertion")
print("="*80)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Confirm Insert into Delta Tables
# MAGIC
# MAGIC Run the cell below. It will create a **widget** at the top of the notebook.
# MAGIC
# MAGIC 1. Review the widget default value (`No`).  
# MAGIC 2. Change it to **`Yes`** when you are ready to persist the analysis results to Unity Catalog.  
# MAGIC 3. Then run the **Insert into Delta Tables** cell immediately after.

# COMMAND ----------

# ─────────────────────────────────────────────────────────────────────────────
# Confirmation Widget
# Change the widget value to "Yes" at the top of the notebook, then run the
# next cell ("Insert into Delta Tables") to persist analysis results.
# ─────────────────────────────────────────────────────────────────────────────

print("="*80)
print("  Widget created above ↑")
print("="*80)
print("""
  Target catalog : dbscannercatalog
  Target schema  : catalog_inventory
  Tables that will be populated:
    • workspace_analysis_cluster_summary
    • workspace_analysis_job_summary
    • workspace_analysis_security_findings
    • workspace_analysis_query_summary        (only if query data was collected)
    • spark_job_optimizer_findings            (only if spark optimizer data was collected)
    • spark_job_optimizer_recommendations     (only if spark optimizer data was collected)

  ➜  Set widget to "Yes", then run the next cell to insert.
""")


# COMMAND ----------


# ─────────────────────────────────────────────────────────────────────────────
# INSERT ANALYSIS RESULTS INTO UNITY CATALOG DELTA TABLES
# ─────────────────────────────────────────────────────────────────────────────

# ── Guard: only proceed when user explicitly confirms ──────────────────────
_confirm = dbutils.widgets.get("confirm_insert")
if _confirm.strip().lower() != "yes":
    print("⚠️  Insertion skipped.")
    print("   Set the 'Save analysis to Delta Tables?' widget to 'Yes' and re-run this cell.")
    raise SystemExit(0)

# ── Dependencies ───────────────────────────────────────────────────────────
import os
import math
import glob
import json
import uuid as _uuid
import pandas as pd
import numpy as np
from datetime import datetime
from pyspark.sql.types import (
    StructType, StructField,
    StringType, TimestampType, IntegerType,
    LongType, DoubleType, BooleanType
)

# ── Run-level metadata ─────────────────────────────────────────────────────
_analysis_run_id = f"AR_{timestamp}"   # timestamp defined in configuration cell
_analysis_ts     = datetime.now()
_CATALOG         = dbutils.widgets.get("_CATALOG")
_SCHEMA          = dbutils.widgets.get("_SCHEMA")

print("="*80)
print("INSERTING ANALYSIS RESULTS INTO UNITY CATALOG DELTA TABLES")
print("="*80)
print(f"  Run ID          : {_analysis_run_id}")
print(f"  Analysis time   : {_analysis_ts.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"  Target catalog  : {_CATALOG}.{_SCHEMA}")
print("  Mode            : APPEND  (filter by analysis_run_id for latest run)")
print("="*80 + "\n")

# ── Ensure catalog and schema exist ───────────────────────────────────────
try:
    spark.sql(f"CREATE CATALOG IF NOT EXISTS `{_CATALOG}`")
    print(f"  ✓ Catalog '{_CATALOG}' ready")
except Exception as _ce:
    print(f"  ⚠️  Could not create catalog (may already exist or lack permissions): {_ce}")
try:
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{_CATALOG}`.`{_SCHEMA}`")
    print(f"  ✓ Schema '{_CATALOG}.{_SCHEMA}' ready\n")
except Exception as _se:
    print(f"  ⚠️  Could not create schema (may already exist or lack permissions): {_se}\n")

_tables_written = []
_tables_skipped = []


# ─────────────────────────────────────────────────────────────────────────────
# Helper: cast pandas DataFrame columns to exact Spark types declared in schema.
# ─────────────────────────────────────────────────────────────────────────────
def _to_spark(pd_df, schema: StructType):
    _PD_MAP = {
        StringType   : lambda s: s.apply(lambda x: str(x) if pd.notna(x) else None),
        IntegerType  : lambda s: pd.to_numeric(s, errors='coerce').astype('Int32'),
        LongType     : lambda s: pd.to_numeric(s, errors='coerce').astype('Int64'),
        DoubleType   : lambda s: pd.to_numeric(s, errors='coerce').astype('float64'),
        BooleanType  : lambda s: s.astype('boolean'),
        TimestampType: lambda s: pd.to_datetime(s, errors='coerce'),
    }
    out = pd_df.copy()
    for field in schema:
        col = field.name
        if col not in out.columns:
            out[col] = None
        caster = _PD_MAP.get(type(field.dataType), lambda s: s)
        try:
            out[col] = caster(out[col])
        except Exception as _ce:
            print(f"    ⚠️  Could not cast column '{col}': {_ce} — leaving as is")
    out = out[[f.name for f in schema]]
    return spark.createDataFrame(out, schema=schema)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: append a Spark DataFrame to a Delta table, self-healing schema
# conflicts by dropping the table and retrying once.
# ─────────────────────────────────────────────────────────────────────────────
def _smart_write(sdf, full_table_name: str):
    _SCHEMA_ERRORS = ("DELTA_MERGE_INCOMPATIBLE_DATATYPE", "DELTA_FAILED_TO_MERGE_FIELDS")
    try:
        (sdf.write
            .format("delta")
            .mode("append")
            .saveAsTable(full_table_name))
    except Exception as _exc:
        _msg = str(_exc)
        if any(e in _msg for e in _SCHEMA_ERRORS):
            print(f"    ⚠️  Schema conflict detected for {full_table_name}.")
            print(f"       Dropping and recreating table with current schema …")
            spark.sql(f"DROP TABLE IF EXISTS {full_table_name}")
            (sdf.write
                .format("delta")
                .mode("append")
                .saveAsTable(full_table_name))
            print(f"    ✓ Table recreated successfully.")
        else:
            raise


# ─────────────────────────────────────────────────────────────────────────────
# Plain-Python coercion helpers — avoid pandas nullable types (Int32/Float64)
# which Spark silently converts to null.
# ─────────────────────────────────────────────────────────────────────────────
def _s(v):
    """Safe string: None for NaN/None, else stripped str."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    return str(v).strip() or None

def _f(v):
    """Safe float: None for NaN/None/non-numeric, else plain Python float."""
    try:
        r = float(v)
        return None if math.isnan(r) else r
    except (TypeError, ValueError):
        return None

def _i(v):
    """Safe int: None for NaN/None/non-numeric, else plain Python int."""
    try:
        r = float(v)
        return None if math.isnan(r) else int(r)
    except (TypeError, ValueError):
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Helper: locate the consolidated cluster Excel file.
#   1. Try cluster_results['cluster_output_file'] (may be deleted by temp cleanup)
#   2. Fall back to newest Cluster_Analysis_Consolidated_*.xlsx in ANALYSIS_OUTPUT
# ─────────────────────────────────────────────────────────────────────────────
def _find_cluster_excel():
    _recorded = cluster_results.get('cluster_output_file', '')
    if _recorded and os.path.exists(_recorded):
        print(f"  ✓ Found Excel at recorded path: {_recorded}")
        return _recorded
    print(f"  ℹ️  Recorded path not found ({_recorded})")
    print(f"      Searching ANALYSIS_OUTPUT: {ANALYSIS_OUTPUT}")
    _candidates = sorted(
        glob.glob(os.path.join(ANALYSIS_OUTPUT, 'Cluster_Analysis_Consolidated_*.xlsx')),
        key=os.path.getmtime, reverse=True
    )
    if _candidates:
        print(f"  ✓ Found Excel in output folder: {_candidates[0]}")
        return _candidates[0]
    print(f"  ❌ No Cluster_Analysis_Consolidated_*.xlsx found in {ANALYSIS_OUTPUT}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
# 1. CLUSTER ANALYSIS  →  workspace_analysis_cluster_summary
# ══════════════════════════════════════════════════════════════════════════════
print("─"*60)
print("STEP 1/5: Inserting cluster analysis …")
print("─"*60)
try:
    _CLUSTER_SHEET = 'utilization_All Clusters'
    _cluster_excel = _find_cluster_excel()

    if _cluster_excel:
        print(f"  Reading sheet '{_CLUSTER_SHEET}' …")
        _cluster_pd = pd.read_excel(_cluster_excel, sheet_name=_CLUSTER_SHEET)
        print(f"  Sheets available : {pd.ExcelFile(_cluster_excel).sheet_names}")
        print(f"  Rows read        : {len(_cluster_pd):,}")
        print(f"  Cols             : {list(_cluster_pd.columns)}")
        if not _cluster_pd.empty:
            print(f"  Row 0            : {_cluster_pd.iloc[0].to_dict()}")
    else:
        _cluster_pd = None

    if _cluster_pd is not None and not _cluster_pd.empty:
        _col_rename = {
            'Avg_CPU_Util'              : 'avg_cpu_utilization',
            'Peak_CPU_Util'             : 'peak_cpu_utilization',
            'Avg_Memory_Util'           : 'avg_memory_utilization',
            'Max_Memory_Util'           : 'max_memory_utilization',
            'Avg_CPU_Wait'              : 'avg_cpu_wait',
            'Max_CPU_Wait'              : 'max_cpu_wait',
            'Avg_Network_MB_Received'   : 'avg_network_mb_received',
            'Avg_Network_MB_Sent'       : 'avg_network_mb_sent',
            'Category'                  : 'category',
            'autoscaling_status'        : 'autoscaling_analysis',
            'Network_Classification'    : 'network_classification',
            'Autoscaling_Recommendation': 'recommendation',
            'Remark'                    : 'recommendation_detail',
        }
        _cluster_pd.rename(columns=_col_rename, inplace=True)

        _cluster_schema = StructType([
            StructField('analysis_run_id',           StringType(),    True),
            StructField('analysis_timestamp',         TimestampType(), True),
            StructField('workspace_id',               StringType(),    True),
            StructField('cluster_id',                 StringType(),    True),
            StructField('cluster_name',               StringType(),    True),
            StructField('job_id',                     StringType(),    True),
            StructField('job_name',                   StringType(),    True),
            StructField('driver_node_type',           StringType(),    True),
            StructField('worker_node_type',           StringType(),    True),
            StructField('min_autoscale_workers',      IntegerType(),   True),
            StructField('max_autoscale_workers',      IntegerType(),   True),
            StructField('avg_cpu_utilization',        DoubleType(),    True),
            StructField('peak_cpu_utilization',       DoubleType(),    True),
            StructField('avg_memory_utilization',     DoubleType(),    True),
            StructField('max_memory_utilization',     DoubleType(),    True),
            StructField('avg_cpu_wait',               DoubleType(),    True),
            StructField('max_cpu_wait',               DoubleType(),    True),
            StructField('avg_network_mb_received',    DoubleType(),    True),
            StructField('avg_network_mb_sent',        DoubleType(),    True),
            StructField('category',                   StringType(),    True),
            StructField('autoscaling_analysis',       StringType(),    True),
            StructField('network_classification',     StringType(),    True),
            StructField('recommendation',             StringType(),    True),
            StructField('recommendation_detail',      StringType(),    True),
        ])

        _cluster_rows = []
        for _, _row in _cluster_pd.iterrows():
            _row = _row.to_dict()
            _cname = _s(_row.get('cluster_name'))
            if not _cname:
                _cname = _s(_row.get('cluster_id'))

            _cluster_rows.append({
                'analysis_run_id'           : _analysis_run_id,
                'analysis_timestamp'        : _analysis_ts,
                'workspace_id'              : '',
                'cluster_id'               : _s(_row.get('cluster_id')),
                'cluster_name'             : _cname,
                'job_id'                   : _s(_row.get('job_id')),
                'job_name'                 : _s(_row.get('job_name')),
                'driver_node_type'         : _s(_row.get('driver_node_type')),
                'worker_node_type'         : _s(_row.get('worker_node_type')),
                'min_autoscale_workers'    : _i(_row.get('min_autoscale_workers')),
                'max_autoscale_workers'    : _i(_row.get('max_autoscale_workers')),
                'avg_cpu_utilization'      : _f(_row.get('avg_cpu_utilization')),
                'peak_cpu_utilization'     : _f(_row.get('peak_cpu_utilization')),
                'avg_memory_utilization'   : _f(_row.get('avg_memory_utilization')),
                'max_memory_utilization'   : _f(_row.get('max_memory_utilization')),
                'avg_cpu_wait'             : _f(_row.get('avg_cpu_wait')),
                'max_cpu_wait'             : _f(_row.get('max_cpu_wait')),
                'avg_network_mb_received'  : _f(_row.get('avg_network_mb_received')),
                'avg_network_mb_sent'      : _f(_row.get('avg_network_mb_sent')),
                'category'                 : _s(_row.get('category')),
                'autoscaling_analysis'     : _s(_row.get('autoscaling_analysis')),
                'network_classification'   : _s(_row.get('network_classification')),
                'recommendation'           : _s(_row.get('recommendation')),
                'recommendation_detail'    : _s(_row.get('recommendation_detail')),
            })

        _cluster_sdf = spark.createDataFrame(_cluster_rows, schema=_cluster_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_cluster_summary"
        _smart_write(_cluster_sdf, _tbl)
        print(f"  ✓ Wrote {_cluster_sdf.count():,} cluster rows  (run_id: {_analysis_run_id})")
        _tables_written.append("workspace_analysis_cluster_summary")
    else:
        print("  ⚠️  Cluster analysis data not found – skipping")
        _tables_skipped.append("workspace_analysis_cluster_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Cluster insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_cluster_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 2. JOB ANALYSIS  →  workspace_analysis_job_summary
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 2/5: Inserting job analysis …")
print("─"*60)
try:
    if data_paths.get('jobs_input') and os.path.exists(data_paths['jobs_input']):
        from databricks_toolkit.analysis.job_analyzer import JobAnalyzer

        _job_analyzer_ins = JobAnalyzer(data_paths['jobs_input'], '/tmp')
        _job_analyzer_ins.load_data()
        _ws_id_job = str(_job_analyzer_ins.metadata.get('workspace_id', ''))

        _job_rows = []
        for _j in _job_analyzer_ins.jobs_data:
            _tasks       = _j.get('tasks', [])
            _runs        = _j.get('recent_runs', [])
            _email_notif = _j.get('email_notifications', {})

            _durations = []
            for _r in _runs:
                _st, _et = _r.get('start_time'), _r.get('end_time')
                if _st and _et:
                    try:
                        # Try integer milliseconds first (original format)
                        if isinstance(_st, (int, float)) and isinstance(_et, (int, float)):
                            _durations.append((_et - _st) / 60000.0)
                        # Try converting string to int milliseconds
                        elif isinstance(_st, str) and isinstance(_et, str):
                            try:
                                _durations.append((int(_et) - int(_st)) / 60000.0)
                            except ValueError:
                                # Handle string datetime format: "MM/DD/YYYY HH:MM:SS"
                                _start_dt = datetime.strptime(_st, "%m/%d/%Y %H:%M:%S")
                                _end_dt = datetime.strptime(_et, "%m/%d/%Y %H:%M:%S")
                                _dur = (_end_dt - _start_dt).total_seconds() / 60
                                if _dur > 0:
                                    _durations.append(_dur)
                    except (ValueError, TypeError):
                        pass

            _has_notif = bool(
                _email_notif.get('on_failure') or
                _email_notif.get('on_success') or
                _email_notif.get('on_start')
            )
            _has_retry = any((t.get('max_retries') or 0) > 0 for t in _tasks)
            _tasks_no_retry = sum(1 for t in _tasks if not (t.get('max_retries') or 0))
            _cluster_types = ','.join({t.get('cluster_type', 'unknown') for t in _tasks})

            _job_rows.append({
                'analysis_run_id'      : _analysis_run_id,
                'analysis_timestamp'   : _analysis_ts,
                'workspace_id'         : _ws_id_job,
                'job_id'               : str(_j.get('job_id', '')),
                'job_name'             : str(_j.get('job_name', 'Unknown')),
                'creator'              : str(_j.get('creator_user_name', 'Unknown')),
                'job_format'           : str(_j.get('format', 'SINGLE_TASK')),
                'task_count'           : len(_tasks),
                'tasks_without_retry'  : _tasks_no_retry,
                'has_retry_policy'     : _has_retry,
                'has_notifications'    : _has_notif,
                'has_recent_failure'   : any(str(r.get('result_state') or '').upper() == 'FAILED' for r in _runs),
                'avg_run_duration_mins': sum(_durations)/len(_durations) if _durations else None,
                'p95_run_duration_mins': sorted(_durations)[int(len(_durations)*0.95)] if len(_durations) >= 2 else (_durations[0] if _durations else None),
                'total_runs_analyzed'  : len(_runs),
                'cluster_types'        : _cluster_types,
            })

        _job_schema = StructType([
            StructField('analysis_run_id',       StringType(),    True),
            StructField('analysis_timestamp',     TimestampType(), True),
            StructField('workspace_id',           StringType(),    True),
            StructField('job_id',                 StringType(),    True),
            StructField('job_name',               StringType(),    True),
            StructField('creator',                StringType(),    True),
            StructField('job_format',             StringType(),    True),
            StructField('task_count',             IntegerType(),   True),
            StructField('tasks_without_retry',    IntegerType(),   True),
            StructField('has_retry_policy',       BooleanType(),   True),
            StructField('has_notifications',      BooleanType(),   True),
            StructField('has_recent_failure',     BooleanType(),   True),
            StructField('avg_run_duration_mins',  DoubleType(),    True),
            StructField('p95_run_duration_mins',  DoubleType(),    True),
            StructField('total_runs_analyzed',    IntegerType(),   True),
            StructField('cluster_types',          StringType(),    True),
        ])

        _job_sdf = _to_spark(pd.DataFrame(_job_rows), _job_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_job_summary"
        _smart_write(_job_sdf, _tbl)
        print(f"  ✓ Wrote {_job_sdf.count():,} job rows")
        _tables_written.append("workspace_analysis_job_summary")
    else:
        print("  ⚠️  Job data path not found – skipping")
        _tables_skipped.append("workspace_analysis_job_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Job insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_job_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 3. SECURITY ANALYSIS  →  workspace_analysis_security_findings
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 3/5: Inserting security findings …")
print("─"*60)
try:
    _sec_available = 'security_results' in vars() or 'security_results' in globals()
    if _sec_available and security_results:
        _findings_list = security_results.get('findings', [])
        _overall_score = int(security_results.get('security_score', 0))
        _ws_id_sec     = str(security_results.get('workspace_id', ''))

        if _findings_list:
            _sec_rows = [{
                'analysis_run_id'       : _analysis_run_id,
                'analysis_timestamp'    : _analysis_ts,
                'workspace_id'          : _ws_id_sec,
                'check_id'              : str(_f.get('check_id', '')),
                'check_name'            : str(_f.get('check_name', '')),
                'category'              : str(_f.get('category_name', _f.get('category', ''))),
                'severity'              : str(_f.get('severity', '')),
                'status'                : str(_f.get('status', '')),
                'score'                 : int(_f.get('severity_score', 0)),
                'finding'               : str(_f.get('current_value', '')),
                'recommendation'        : str(_f.get('recommendation', '')),
                'detail'                : str(_f.get('expected_value', '')),
                'overall_security_score': _overall_score,
            } for _f in _findings_list]

            _sec_schema = StructType([
                StructField('analysis_run_id',        StringType(),    True),
                StructField('analysis_timestamp',      TimestampType(), True),
                StructField('workspace_id',            StringType(),    True),
                StructField('check_id',                StringType(),    True),
                StructField('check_name',              StringType(),    True),
                StructField('category',                StringType(),    True),
                StructField('severity',                StringType(),    True),
                StructField('status',                  StringType(),    True),
                StructField('score',                   IntegerType(),   True),
                StructField('finding',                 StringType(),    True),
                StructField('recommendation',          StringType(),    True),
                StructField('detail',                  StringType(),    True),
                StructField('overall_security_score',  IntegerType(),   True),
            ])

            _sec_sdf = _to_spark(pd.DataFrame(_sec_rows), _sec_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_security_findings"
            _smart_write(_sec_sdf, _tbl)
            print(f"  ✓ Wrote {_sec_sdf.count():,} security finding rows  (score: {_overall_score}/100)")
            _tables_written.append("workspace_analysis_security_findings")
        else:
            print("  ⚠️  No security findings in results – skipping")
            _tables_skipped.append("workspace_analysis_security_findings")
    else:
        print("  ⚠️  Security analysis was not run or failed – skipping")
        _tables_skipped.append("workspace_analysis_security_findings")
except Exception as _e:
    import traceback
    print(f"  ❌ Security insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_security_findings")


# ══════════════════════════════════════════════════════════════════════════════
# 4. QUERY ANALYSIS  →  workspace_analysis_query_summary
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 4/5: Inserting query analysis …")
print("─"*60)
try:
    _query_available = (
        ('query_analyzer' in vars() or 'query_analyzer' in globals()) and
        getattr(query_analyzer, 'query_data', None) is not None and
        not query_analyzer.query_data.empty
    )
    if _query_available:
        _q_pd = query_analyzer.query_data.copy()

        _q_rename = {
            'query_id'          : 'query_id',
            'warehouse_id'      : 'warehouse_id',
            'executed_by'       : 'user_name',
            'statement_text'    : 'query_text_preview',
            'total_duration_ms' : 'duration_ms',
            'rows_produced'     : 'rows_produced',
            'estimated_dbu_cost': 'bytes_scanned',
            'error_message'     : 'recommendation',
        }
        _q_pd.rename(columns={k: v for k, v in _q_rename.items() if k in _q_pd.columns}, inplace=True)

        if 'duration_ms' in _q_pd.columns:
            _q_pd['duration_mins']   = pd.to_numeric(_q_pd['duration_ms'], errors='coerce') / 60000.0
            _q_pd['is_long_running'] = pd.to_numeric(_q_pd['duration_ms'], errors='coerce') > 300_000
        else:
            _q_pd['duration_mins']   = None
            _q_pd['is_long_running'] = None

        if 'query_text_preview' in _q_pd.columns:
            _q_pd['query_text_preview'] = _q_pd['query_text_preview'].astype(str).str[:500]

        def _perf_cat(ms):
            try:
                ms = float(ms)
            except (TypeError, ValueError):
                return 'Unknown'
            if ms < 5_000:   return 'Fast'
            if ms < 60_000:  return 'Normal'
            if ms < 300_000: return 'Slow'
            return 'Very Slow'
        _q_pd['performance_category'] = _q_pd.get('duration_ms', pd.Series(dtype=float)).apply(_perf_cat)

        _q_pd['analysis_run_id']    = _analysis_run_id
        _q_pd['analysis_timestamp'] = _analysis_ts
        _q_pd['workspace_id']       = ''

        _q_schema = StructType([
            StructField('analysis_run_id',      StringType(),    True),
            StructField('analysis_timestamp',    TimestampType(), True),
            StructField('workspace_id',          StringType(),    True),
            StructField('query_id',              StringType(),    True),
            StructField('warehouse_id',          StringType(),    True),
            StructField('user_name',             StringType(),    True),
            StructField('query_text_preview',    StringType(),    True),
            StructField('duration_ms',           DoubleType(),    True),
            StructField('duration_mins',         DoubleType(),    True),
            StructField('rows_produced',         DoubleType(),    True),
            StructField('bytes_scanned',         DoubleType(),    True),
            StructField('is_long_running',       BooleanType(),   True),
            StructField('performance_category',  StringType(),    True),
            StructField('recommendation',        StringType(),    True),
        ])

        _q_sdf = _to_spark(_q_pd, _q_schema)
        _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_query_summary"
        _smart_write(_q_sdf, _tbl)
        print(f"  ✓ Wrote {_q_sdf.count():,} query rows")
        _tables_written.append("workspace_analysis_query_summary")
    else:
        print("  ⚠️  Query analysis was not run or has no data – skipping")
        _tables_skipped.append("workspace_analysis_query_summary")
except Exception as _e:
    import traceback
    print(f"  ❌ Query insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("workspace_analysis_query_summary")


# ══════════════════════════════════════════════════════════════════════════════
# 5. SPARK JOB OPTIMIZER  →  spark_job_optimizer_findings
#                           →  spark_job_optimizer_recommendations
#
#    Iterates over Spark-only ScanResult finding DataFrames and inserts them.
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "─"*60)
print("STEP 5/5: Inserting Spark Job Optimizer findings & recommendations …")
print("─"*60)
try:
    _sjo_ok = (sjo_scan_result is not None and sjo_scan_result.total_findings > 0)
    if _sjo_ok:
        _sjo_ts    = sjo_scan_result.scan_timestamp
        _sjo_ws_id = sjo_scan_result.workspace_id

        # Generate recommendations (same engine used inside generate_report())
        _sjo_recs = SparkRecommendationEngine({}).generate_recommendations(sjo_scan_result)

        # ── Build findings rows (Spark-only; UC Delta findings handled separately) ──
        _CAT_MAP = [
            ('skewed_jobs',          'data_skew'),
            ('shuffle_spill_jobs',   'shuffle_spill'),
            ('broadcast_candidates', 'broadcast_candidates'),
            ('broadcast_joins',      'broadcast_candidates'),  # compatibility alias
            ('long_running_jobs',    'long_running_jobs'),
            ('failed_tasks',         'failed_tasks'),
        ]
        def _sev_for(cat, rd):
            d = str(rd.get('issue_description', '')).upper()
            if 'CRITICAL' in d:
                return 'HIGH'
            if 'WARNING' in d:
                return 'MEDIUM'
            if cat == 'failed_tasks':
                return 'HIGH' if float(rd.get('failure_pct', 0) or 0) >= 50 else 'MEDIUM'
            if cat == 'data_skew':
                return 'HIGH' if float(rd.get('skew_ratio', 0) or 0) >= 20 else 'MEDIUM'
            if cat == 'shuffle_spill':
                return 'HIGH' if float(rd.get('spill_mb', 0) or 0) >= 1000 else 'MEDIUM'
            return 'MEDIUM'

        _finding_rows = []
        _seen_attr = set()
        for _attr, _category in _CAT_MAP:
            if _attr in _seen_attr:
                continue
            _seen_attr.add(_attr)
            _raw_df = getattr(sjo_scan_result, _attr, None)
            if _raw_df is None or (hasattr(_raw_df, 'empty') and _raw_df.empty):
                continue
            for _, _row in _raw_df.iterrows():
                _rd = _row.to_dict()
                _finding_rows.append({
                    'finding_id'      : str(_uuid.uuid4()),
                    'scan_id'         : _analysis_run_id,
                    'workspace_id'    : _sjo_ws_id,
                    'workspace_name'  : sjo_scan_result.workspace_name,
                    'scan_timestamp'  : _sjo_ts,
                    'lookback_days'   : sjo_scan_result.lookback_days,
                    'category'        : _category,
                    'severity'        : _sev_for(_category, _rd),
                    'job_id'          : _s(_rd.get('job_id',        '')),
                    'run_id'          : _s(_rd.get('run_id',        '')),
                    'query_id'        : _s(_rd.get('query_id',      '')),
                    'table_catalog'   : _s(_rd.get('table_catalog', '')),
                    'table_schema'    : _s(_rd.get('table_schema',  '')),
                    'table_name'      : _s(_rd.get('table_name',    '')),
                    'skew_ratio'      : _f(_rd.get('skew_ratio')),
                    'spill_mb'        : _f(_rd.get('spill_mb')),
                    'read_mb'         : _f(_rd.get('read_mb')),
                    'num_files'       : _f(_rd.get('num_files')),
                    'duration_mins'   : _f(_rd.get('duration_mins')),
                    'failure_pct'     : _f(_rd.get('failure_pct')),
                    'days_since_alter': _i(_rd.get('days_since_last_alter') if _rd.get('days_since_last_alter') is not None else _rd.get('days_since_alter')),
                    'details_json'    : json.dumps(
                        {k: str(v) for k, v in _rd.items()}, default=str
                    ),
                })
        _spark_cats = {'data_skew', 'shuffle_spill', 'broadcast_candidates', 'long_running_jobs', 'failed_tasks'}
        _bad_rows = sum(1 for r in _finding_rows if r.get('category') not in _spark_cats)
        if _bad_rows:
            print(f"  ℹ️  Skipping {_bad_rows} non-spark findings in Spark table insert")
            _finding_rows = [r for r in _finding_rows if r.get('category') in _spark_cats]

        if _finding_rows:
            _findings_schema = StructType([
                StructField('finding_id',       StringType(),    True),
                StructField('scan_id',          StringType(),    True),
                StructField('workspace_id',     StringType(),    True),
                StructField('workspace_name',   StringType(),    True),
                StructField('scan_timestamp',   TimestampType(), True),
                StructField('lookback_days',    IntegerType(),   True),
                StructField('category',         StringType(),    True),
                StructField('severity',         StringType(),    True),
                StructField('job_id',           StringType(),    True),
                StructField('run_id',           StringType(),    True),
                StructField('query_id',         StringType(),    True),
                StructField('table_catalog',    StringType(),    True),
                StructField('table_schema',     StringType(),    True),
                StructField('table_name',       StringType(),    True),
                StructField('skew_ratio',       DoubleType(),    True),
                StructField('spill_mb',         DoubleType(),    True),
                StructField('read_mb',          DoubleType(),    True),
                StructField('num_files',        DoubleType(),    True),
                StructField('duration_mins',    DoubleType(),    True),
                StructField('failure_pct',      DoubleType(),    True),
                StructField('days_since_alter', IntegerType(),   True),
                StructField('details_json',     StringType(),    True),
            ])
            _findings_sdf = spark.createDataFrame(_finding_rows, schema=_findings_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.spark_job_optimizer_findings"
            _smart_write(_findings_sdf, _tbl)
            print(f"  ✓ Wrote {_findings_sdf.count():,} finding rows  → spark_job_optimizer_findings")
            _tables_written.append("spark_job_optimizer_findings")
        else:
            print("  ⚠️  No findings to write")
            _tables_skipped.append("spark_job_optimizer_findings")

        # ── Build recommendations rows ───────────────────────────────────────
        if _sjo_recs:
            _rec_rows = [{
                'recommendation_id': r.recommendation_id,
                'scan_id'          : _analysis_run_id,
                'workspace_id'     : _sjo_ws_id,
                'scan_timestamp'   : _sjo_ts,
                'finding_id'       : r.finding_id,
                'category'         : r.category,
                'priority'         : r.priority,
                'issue_summary'    : r.issue_summary,
                'actions'          : '\n'.join(r.actions if isinstance(r.actions, list) else [str(r.actions)]),
                'sql_scripts'      : '\n\n'.join(r.sql_scripts if isinstance(r.sql_scripts, list) else [str(r.sql_scripts)]),
                'estimated_savings': r.estimated_savings,
                'reference_docs'   : '\n'.join(r.reference_docs if isinstance(r.reference_docs, list) else [str(r.reference_docs)]),
            } for r in _sjo_recs]

            _rec_schema = StructType([
                StructField('recommendation_id', StringType(),    True),
                StructField('scan_id',           StringType(),    True),
                StructField('workspace_id',      StringType(),    True),
                StructField('scan_timestamp',    TimestampType(), True),
                StructField('finding_id',        StringType(),    True),
                StructField('category',          StringType(),    True),
                StructField('priority',          StringType(),    True),
                StructField('issue_summary',     StringType(),    True),
                StructField('actions',           StringType(),    True),
                StructField('sql_scripts',       StringType(),    True),
                StructField('estimated_savings', StringType(),    True),
                StructField('reference_docs',    StringType(),    True),
            ])
            _rec_sdf = _to_spark(pd.DataFrame(_rec_rows), _rec_schema)
            _tbl = f"`{_CATALOG}`.`{_SCHEMA}`.spark_job_optimizer_recommendations"
            _smart_write(_rec_sdf, _tbl)
            print(f"  ✓ Wrote {_rec_sdf.count():,} recommendation rows  → spark_job_optimizer_recommendations")
            _tables_written.append("spark_job_optimizer_recommendations")
        else:
            print("  ⚠️  No recommendations generated")
            _tables_skipped.append("spark_job_optimizer_recommendations")
    else:
        print("  ⚠️  Spark optimizer scan result not available — skipping")
        _tables_skipped.append("spark_job_optimizer_findings")
        _tables_skipped.append("spark_job_optimizer_recommendations")
except Exception as _e:
    import traceback
    print(f"  ❌ Spark Job Optimizer insert failed: {_e}")
    traceback.print_exc()
    _tables_skipped.append("spark_job_optimizer_findings")
    _tables_skipped.append("spark_job_optimizer_recommendations")


# ══════════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "="*80)
print("  DELTA INSERT COMPLETE")
print("="*80)
print(f"\n  Run ID : {_analysis_run_id}")
print(f"\n  ✅ Tables written ({len(_tables_written)}):")
for _t in _tables_written:
    print(f"       {_CATALOG}.{_SCHEMA}.{_t}")
if _tables_skipped:
    print(f"\n  ⚠️  Tables skipped ({len(_tables_skipped)}):")
    for _t in _tables_skipped:
        print(f"       {_t}")

print(f"\n  To query only the latest run's cluster results:")
print(f"    SELECT * FROM `{_CATALOG}`.`{_SCHEMA}`.workspace_analysis_cluster_summary")
print(f"    WHERE analysis_run_id = '{_analysis_run_id}';")
print("\n" + "="*80)